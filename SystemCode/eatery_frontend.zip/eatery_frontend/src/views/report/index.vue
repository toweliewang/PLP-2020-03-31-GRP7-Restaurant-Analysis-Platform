<template>
  <div class="log">
    <sticky-top>
      <div class="log-header">
        <div class="header-left"><p class="title">Eatery Reports</p></div>
        <div class="header-right">
          <!-- <lin-search ref="searchKeyword" @query="onQueryChange" /> -->
          <el-dropdown size="medium" style="margin: 0 10px;" @command="handleCommand">
            <el-button size="medium">
              {{ eatery.name }} <i class="el-icon-arrow-down el-icon--right" />
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                v-for="(_eatery, index) in eateries"
                :key="index"
                :command="_eatery.id"
                icon="el-icon-s-shop"
              >{{ _eatery.name }}
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
      <el-divider v-if="!keyword" />
    </sticky-top>
    <transition name="fade">
      <div v-if="keyword" class="search">
        <p class="search-tip">
          搜索“<span class="search-keyword">{{ keyword }}</span>”， 找到 <span class="search-num">{{ totalCount }}</span> 条日志信息
        </p>
        <button class="search-back" @click="backInit">返回全部日志</button>
      </div>
    </transition>
    <div class="content lin-wrap-ui">
      <el-row :gutter="30">
        <el-col :span="5">
          <el-card class="box-card eatery-card">
            <div class="personal">
              <div class="personal-title">
                <div style="float:left;">
                  Eatery Information
                </div>
              </div>
              <el-divider />
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Name</div>
                  <div class="personal-influence-num color1">{{ eatery.name }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Owner</div>
                  <div class="personal-influence-num color1">{{ eatery.owner.name }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Cuisine</div>
                  <div class="personal-influence-num color1">{{ eatery.cuisine }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Phone</div>
                  <div class="personal-influence-num color1">{{ eatery.phone }}</div>
                </div>
              </div>
              <div class="personal-influence" style="margin-bottom:15px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Rating</div>
                  <el-rate
                    v-model="eatery.rating"
                    style="margin-top:10px;"
                    disabled
                    show-score
                    text-color="#ff9900"
                    score-template="{value}"
                  />
                </div>
              </div>
              <el-divider />
              <div class="personal-influence" style="margin-bottom:15px;height:100px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Address</div>
                  <div class="personal-influence-num longcontent color3">
                    <i class="el-icon-location-information" />
                    {{ eatery.address }}</div>
                  <div class="personal-influence-num longcontent">
                    <i class="el-icon-discover" />
                    {{ eatery.from_info }}</div>
                </div>
              </div>
              <el-divider />
              <el-collapse accordion style="margin-top:-10px;">
                <el-collapse-item name="1">
                  <template slot="title" style="text-align:left;">
                    Description
                  </template>
                  <div>
                    {{ eatery.description }}
                  </div>
                </el-collapse-item>
              </el-collapse>
            </div>
          </el-card>

        </el-col>
        <el-col :span="19">
          <el-card style="margin-bottom:25px;">
            <div slot="header" class="card-header">
              <div class="header-left"><p class="title">Reports Info</p></div>
              <!-- <div class="header-right">
                <el-button type="primary" style="margin-right:15px;" round>主要按钮</el-button>
                <lin-date-picker ref="searchDate" class="date" style="margin-right:20px;" @dateChange="handleDateChange" />
              </div> -->
            </div>
            <el-table v-show="openSearchPanel" v-loading="loading" fit :data="tableData" height="400" style="width: 100%;border:0px;margin-top:-35px;margin-left:-10px;margin-right:-15px;">
              <el-table-column
                prop="id"
                label="ID"
                align="center"
              />
              <el-table-column
                prop="create_time"
                label="Generate Date"
              />
              <el-table-column
                prop="report_range"
                label="Report Range"
              />
              <el-table-column label="Action">
                <template slot-scope="scope">
                  <el-button
                    type="primary"
                    plain
                    size="mini"
                    @click="handleClick(scope.row)"
                  >Check</el-button>
                </template>

              </el-table-column>
            </el-table>
            <el-table v-show="!openSearchPanel" fit :data="selected_tableData" style="width: 100%;border:0px;margin-top:-35px;margin-left:-10px;margin-right:-15px;">
              <el-table-column
                prop="id"
                label="ID"
              />
              <el-table-column
                prop="create_time"
                label="Generate Date"
              />
              <el-table-column
                prop="report_range"
                label="Report Range"
              />
              <el-table-column label="Action">
                <template slot-scope="scope">
                  <el-button
                    type="primary"
                    plain
                    size="mini"
                    @click="refresh()"
                  >Back</el-button>
                </template>

              </el-table-column>
            </el-table>
          </el-card>

          <div v-if="openReportPanel" :ref="reportPanel" class="reportPanel">
            <el-row :gutter="20">
              <el-col :span="24">
                <el-card style="margin-bottom:25px;min-height:280px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Actions need to do</p></div>
                  </div>
                  <div style="margin-top:-20px;padding:15px auto;">
                    <el-divider content-position="left">Overall</el-divider>
                    <span class="summary" v-html="overall_summary" />
                    <el-divider content-position="left">Food</el-divider>
                    <span class="summary" v-html="food_summary" />
                  </div>

                </el-card>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="overall_score_switch_size">
                <el-card style="margin-bottom:25px;min-height:430px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Overall Sentiments Score</p></div>
                    <div class="header-right">
                      <el-tooltip class="item" effect="dark" content="Week/History" placement="top-start">
                        <el-button icon="el-icon-data-analysis" circle style="border:0px;font-size:20px;" @click="overall_score_switch = !overall_score_switch" />
                      </el-tooltip>

                    </div>
                  </div>
                  <bar-chart v-if="!overall_score_switch" :chartdata="overall_report.one_all" />
                  <line-chart v-if="overall_score_switch" :chartdata="overall_report.all" />
                </el-card>
              </el-col>
              <el-col :span="sentiment_score_switch_size">
                <el-card style="margin-bottom:25px;min-height:430px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Sentiments Score by Category</p></div>
                    <div class="header-right">
                      <el-tooltip class="item" effect="dark" content="Week/History" placement="top-start">
                        <el-button icon="el-icon-data-analysis" circle style="border:0px;font-size:20px;" @click="sentiment_score_switch = !sentiment_score_switch" />
                      </el-tooltip>

                    </div>
                  </div>
                  <npbar-chart v-if="!sentiment_score_switch" :chartdata="sentiment_report.one" @handleNbarCharClick="handleNbarCharClick" />
                  <sline-chart v-if="sentiment_score_switch" :chartdata="sentiment_report.all" />
                </el-card>
              </el-col>
            </el-row>
            <el-row v-if="service_report_show" :gutter="20">
              <el-col :span="24">
                <el-card style="margin-bottom:25px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Service</p></div>
                    <div class="header-right">
                      <el-tooltip class="item" effect="dark" content="Week/History" placement="top-start">
                        <el-button icon="el-icon-data-analysis" circle style="border:0px;font-size:20px;" />
                      </el-tooltip>

                    </div>
                  </div>
                  <el-row :gutter="20">
                    <el-col :span="8">
                      <el-row style="height:300px;width:100%;padding-top:50px;" type="flex" justify="center">
                        <div
                          style="display: flex;flex-flow: column;align-items:center;"
                        >
                          <el-button circle style="border:0px;font-size:180px;color:yellow" @click="service_data_type = 'positive'">
                            <svg t="1584547167193" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="22656" width="200" height="200"><path d="M512 512m-512 0a512 512 0 1 0 1024 0 512 512 0 1 0-1024 0Z" fill="#5DD7D2" p-id="22657" /><path d="M512 0C794.775704 0 1024 229.224296 1024 512S794.775704 1024 512 1024 0 794.775704 0 512 229.224296 0 512 0z m0 75.851852C271.132444 75.851852 75.851852 271.132444 75.851852 512S271.132444 948.148148 512 948.148148 948.148148 752.867556 948.148148 512 752.867556 75.851852 512 75.851852z" fill="#FFFFFF" p-id="22658" /><path d="M512.113778 720.592593c89.505185 0 166.987852-53.589333 203.965629-131.375408 2.730667-5.764741 4.513185-12.212148 4.513186-19.076741 0-21.617778-17.066667-39.063704-38.07763-39.177481a37.850074 37.850074 0 0 0-34.512593 22.110815c-24.007111 53.096296-76.155259 89.884444-136.495407 89.884444-60.302222 0-111.616-36.901926-135.736889-89.770666 0-0.113778-0.113778-0.227556-0.113778-0.37926A38.039704 38.039704 0 0 0 341.485037 530.962963C320.436148 530.962963 303.407407 548.560593 303.407407 570.140444c0 6.106074 1.403259 11.984593 3.906371 17.218371 36.522667 78.772148 114.460444 133.233778 204.8 133.233778zM611.479704 361.206519a54.537481 54.537481 0 1 0 109.074963 0 54.537481 54.537481 0 0 0-109.074963 0M303.407407 361.206519a54.537481 54.537481 0 1 0 109.074963 0 54.537481 54.537481 0 0 0-109.074963 0" fill="#FFFFFF" p-id="22659" /></svg>
                          </el-button>
                          <count-to :start-val="0" :end-val="splited_report.service.positive.num" :duration="3" :prefix="prefix" style="font-size: 20px;" />
                        </div>

                        <div
                          style="display: inline-block;
                              background-color: #DCDFE6;
    width: 2px;
    height: 180px;
    margin: 0 8px;
    vertical-align: middle;
    position: relative;"
                        />
                        <div style="display: flex;flex-flow: column;align-items:center;">
                          <el-button style="border:0px;font-size:180px;" @click="service_data_type = 'negative'">
                            <svg t="1584547034686" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="19879" width="200" height="200"><path d="M512 102c-226.415 0-410 183.585-410 410s183.585 410 410 410 410-183.585 410-410-183.585-410-410-410z" fill="#7ADECA" p-id="19880" /><path d="M307 428.719c0-24.261 19.667-43.929 43.929-43.929 24.26 0 43.928 19.668 43.928 43.929 0 24.26-19.667 43.928-43.928 43.928-24.262 0-43.929-19.667-43.929-43.928z m322.143 0c0-24.261 19.667-43.929 43.928-43.929 24.262 0 43.929 19.668 43.929 43.929 0 24.26-19.667 43.928-43.929 43.928-24.26 0-43.928-19.667-43.928-43.928zM512 531.219c78.248 0 142.402 61.591 146.429 138.74 0.183 4.21-3.112 7.688-7.322 7.688h-44.02c-3.844 0-7.138-2.928-7.413-6.772-3.386-45.301-41.457-81.085-87.674-81.085-46.217 0-84.196 35.784-87.674 81.085-0.275 3.844-3.57 6.772-7.413 6.772h-44.02c-4.21 0-7.505-3.477-7.322-7.687 4.027-77.15 68.181-138.741 146.429-138.741z" fill="#10342D" p-id="19881" /></svg>
                          </el-button>
                          <count-to :start-val="0" :end-val="splited_report.service.negative.num" :duration="3" :prefix="prefix" style="font-size: 20px;" />
                        </div>
                      </el-row>
                    </el-col>
                    <el-col :span="16">
                      <el-table :data="service_data" height="350" style="width: 100%;border:0px;margin:0px -20px;margin-top:-30px;">
                        <el-table-column
                          align="left"
                          prop="sentiment_type"
                          label="Type"
                          fixed
                          width="130"
                        />
                        <el-table-column
                          align="left"
                          prop="content"
                          label="Review"
                        />
                      </el-table>
                    </el-col>
                  </el-row>

                </el-card>
              </el-col>
            </el-row>
            <el-row v-if="food_report_show" :gutter="20">
              <el-col :span="24">
                <el-card style="margin-bottom:25px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Food</p></div>
                    <div class="header-right">
                      <el-tooltip class="item" effect="dark" content="Week/History" placement="top-start">
                        <el-button icon="el-icon-data-analysis" circle style="border:0px;font-size:20px;" />
                      </el-tooltip>

                    </div>
                  </div>
                  <el-row :gutter="20">
                    <el-col :span="10">
                      <word-cloud :worddata="splited_report.food.words" @foodclick="handleFoodClick" />
                    </el-col>
                    <el-col :span="14">
                      <fnpbar-chart :chartdata="splited_report.food.review" @foodclick="handleFoodClick" />
                    </el-col>
                    <el-col :span="24">
                      <el-table :data="food_data" height="300" style="width: 100%;border:0px;margin-top:-40px;">
                        <el-table-column
                          align="left"
                          prop="sentiment_type"
                          label="Type"
                          fixed
                          width="130"
                        />
                        <el-table-column
                          align="left"
                          prop="content"
                          label="Review"
                        />
                      </el-table>
                    </el-col>
                  </el-row>

                </el-card>
              </el-col>
            </el-row>
            <el-row v-if="price_report_show" :gutter="20">
              <el-col :span="24">
                <el-card style="margin-bottom:25px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Price</p></div>
                    <div class="header-right">
                      <el-tooltip class="item" effect="dark" content="Week/History" placement="top-start">
                        <el-button icon="el-icon-data-analysis" circle style="border:0px;font-size:20px;" />
                      </el-tooltip>

                    </div>
                  </div>
                  <el-row :gutter="20">
                    <el-col :span="10">
                      <radar-chart
                        style="margin-top: 20px;"
                        :positive="splited_report.price.positive.num"
                        :negative="splited_report.price.negative.num"
                        :neutral="splited_report.price.neutral.num"
                        @radarclick="handleRadarClick"
                      />
                    </el-col>
                    <el-col :span="14">
                      <el-table :data="price_data" height="350" style="width: 100%;border:0px;margin:0px -20px;margin-top:-30px;">
                        <el-table-column
                          align="left"
                          prop="sentiment_type"
                          label="Type"
                          fixed
                          width="130"
                        />
                        <el-table-column
                          align="left"
                          prop="content"
                          label="Review"
                        />
                      </el-table>
                    </el-col>
                  </el-row>

                </el-card>
              </el-col>
            </el-row>
            <el-row v-if="env_report_show" :gutter="20">
              <el-col :span="24">
                <el-card style="margin-bottom:25px;">
                  <div slot="header" class="card-header">
                    <div class="header-left"><p class="title">Environment</p></div>
                    <div class="header-right">
                      <el-tooltip class="item" effect="dark" content="Week/History" placement="top-start">
                        <el-button icon="el-icon-data-analysis" circle style="border:0px;font-size:20px;" />
                      </el-tooltip>

                    </div>
                  </div>
                  <el-row :gutter="20">
                    <el-col :span="8">
                      <el-row style="height:350px;width:100%;padding-top:50px;" type="flex" justify="center">
                        <div
                          style="display: flex;flex-flow: column;align-items:center;"
                        >
                          <el-button circle style="border:0px;font-size:180px;color:yellow" @click="env_data_type = 'positive'">
                            <svg t="1584545703767" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="15515"><path d="M122.4 671.6c43.8-253.1 158.4-346.5 294.2-384.7 169.7-46.7 318.2-12.7 461-80.6 86.3-41 83.4 32.5 82 43.8C938.4 419.9 847.8 579.7 656.9 656 449 739.5 242.6 585.3 94.1 827.2c-1.4 1.4-2.8 2.8-5.7 2.8H70c-4.2 0-7.1-4.2-5.7-8.5C120.9 709.8 201.5 615 304.8 538.7c93.3-69.3 203.6-121.6 330.9-164 9.9-2.8 5.7-18.4-4.2-17-97.6 22.6-186.7 52.3-268.7 99-86.3 49.4-165.5 117.3-240.4 214.9" fill="#3CB371" p-id="15516" /></svg>
                          </el-button>
                          <count-to :start-val="0" :end-val="splited_report.environment.positive.num" :duration="3" :prefix="prefix" style="font-size: 20px;font-weight:bold;" />
                        </div>

                        <div
                          style="display: inline-block;
                              background-color: #DCDFE6;
                              margin-top:6px;
    width: 2px;
    height: 180px;
    margin: 0 8px;
    vertical-align: middle;
    position: relative;"
                        />
                        <div style="display: flex;flex-flow: column;align-items:center;">
                          <el-button circle style="border:0px;font-size:180px;" @click="env_data_type = 'negative'">
                            <svg t="1584545703767" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="15515"><path d="M122.4 671.6c43.8-253.1 158.4-346.5 294.2-384.7 169.7-46.7 318.2-12.7 461-80.6 86.3-41 83.4 32.5 82 43.8C938.4 419.9 847.8 579.7 656.9 656 449 739.5 242.6 585.3 94.1 827.2c-1.4 1.4-2.8 2.8-5.7 2.8H70c-4.2 0-7.1-4.2-5.7-8.5C120.9 709.8 201.5 615 304.8 538.7c93.3-69.3 203.6-121.6 330.9-164 9.9-2.8 5.7-18.4-4.2-17-97.6 22.6-186.7 52.3-268.7 99-86.3 49.4-165.5 117.3-240.4 214.9" fill="#FF8C00" p-id="15516" /></svg>
                          </el-button>
                          <count-to :start-val="0" :end-val="splited_report.environment.negative.num" :duration="3" :prefix="prefix" style="font-size: 20px;font-weight:bold;" />
                        </div>
                      </el-row>
                    </el-col>
                    <el-col :span="16">
                      <el-table :data="environment_data" height="360" style="width: 100%;border:0px;margin:0px -20px;margin-top:-30px;">
                        <el-table-column
                          align="left"
                          prop="sentiment_type"
                          label="Type"
                          fixed
                          width="100"
                        />
                        <el-table-column
                          align="left"
                          prop="content"
                          label="Review"
                        />
                      </el-table>
                    </el-col>
                  </el-row>

                </el-card>
              </el-col>
            </el-row>
          </div>

        </el-col>
      </el-row>

    </div>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'
import log from 'lin/models/log'
import { searchLogKeyword } from 'lin/utils/search'
import LinDatePicker from '@/components/base/date-picker/lin-date-picker'
import BarChart from '@/components/echarts/BarChart'
import LineChart from '@/components/echarts/LineChart'
import SlineChart from '@/components/echarts/SLineChart'
import RadarChart from '@/components/echarts/RadarChart'
import NpbarChart from '@/components/echarts/NPBarChart'
import FnpbarChart from '@/components/echarts/FNPBarChart'
import WordCloud from '@/components/echarts/WordCloud'
import countTo from 'vue-count-to'

import Report from '@/models/report'
import Eatery from '@/models/eatery'

export default {
  components: {
    BarChart,
    countTo,
    FnpbarChart,
    LineChart,
    SlineChart,
    RadarChart,
    NpbarChart,
    WordCloud
  },
  data() {
    return {
      log: null,
      value: '',
      logs: [],
      users: [],
      searchUser: '',
      more: false,
      loading: true,
      finished: false,
      isSearch: false,
      error: false,
      searchKeyword: '',
      searchDate: [],
      keyword: null,
      totalCount: 0,
      openSearchPanel: true,
      openReportPanel: false,
      eatery: {},
      reports: [],
      tableData: [],
      selected_tableData: [],
      overall_score_switch: false,
      sentiment_score_switch: false,
      service_report_show: false,
      food_report_show: false,
      price_report_show: false,
      env_report_show: false,
      service_data_type: 'all',
      price_data_type: 'all',
      food_data_type: 'all',
      env_data_type: 'all',
      current_eatery_id: 0,
      eateries: []
    }
  },
  computed: {
    ...mapGetters(['user']),
    overall_score_switch_size() {
      if (this.overall_score_switch) {
        return 24
      } else {
        return 12
      }
    },
    sentiment_score_switch_size() {
      if (this.sentiment_score_switch) {
        return 24
      } else {
        return 12
      }
    },
    service_data() {
      let _review = []
      if (this.service_data_type === 'all') {
        _review = _review.concat(this.splited_report.service.negative.review)
        _review = _review.concat(this.splited_report.service.positive.review)
      }
      if (this.service_data_type === 'positive') {
        _review = this.splited_report.service.positive.review
      }
      if (this.service_data_type === 'negative') {
        _review = this.splited_report.service.negative.review
      }
      console.log(_review)
      return _review
    },
    food_data() {
      let _review = []
      let select_entity = {}
      this.splited_report.food.review.forEach(element => {
        if (element.entity === this.food_data_type) {
          select_entity = element
        }
      })
      console.log(select_entity)
      _review = _review.concat(select_entity.positive.review)
      _review = _review.concat(select_entity.negative.review)
      return _review
    },
    price_data() {
      let _review = []
      if (this.price_data_type === 'all') {
        _review = _review.concat(this.splited_report.price.positive.review)
        _review = _review.concat(this.splited_report.price.negative.review)
        _review = _review.concat(this.splited_report.price.neutral.review)
      }
      if (this.price_data_type === 'positive') {
        _review = this.splited_report.price.positive.review
      }
      if (this.price_data_type === 'neutral') {
        _review = this.splited_report.price.neutral.review
      }
      if (this.price_data_type === 'negative') {
        _review = this.splited_report.price.negative.review
      }
      console.log(_review)
      return _review
    },
    environment_data() {
      let _review = []
      if (this.env_data_type === 'all') {
        _review = _review.concat(this.splited_report.environment.negative.review)
        _review = _review.concat(this.splited_report.environment.positive.review)
      }
      if (this.env_data_type === 'positive') {
        _review = this.splited_report.environment.positive.review
      }
      if (this.env_data_type === 'negative') {
        _review = this.splited_report.environment.negative.review
      }
      console.log(_review)
      return _review
    }
  },
  watch: {
    // // 用户搜索
    // searchUser(user) {
    //   this.keyword = user
    //   if (this.searchKeyword) {
    //     this.keyword = `${user} ${this.searchKeyword}`
    //   }
    //   if (this.searchDate.length) {
    //     this.keyword = `${user} ${this.searchKeyword} ${this.searchDate}`
    //   }
    //   this.searchPage()
    // },
    // // 关键字搜索
    // searchKeyword(newVal) {
    //   if (newVal) {
    //     this.keyword = newVal
    //     if (this.searchUser) {
    //       this.keyword = `${this.searchUser} ${newVal}`
    //     }
    //     if (this.searchDate.length) {
    //       this.keyword = `${this.searchUser} ${newVal} ${this.searchDate}`
    //     }
    //   } else {
    //     this.keyword = ''
    //     if (this.searchUser) {
    //       this.keyword = `${this.searchUser}`
    //     }
    //     if (this.searchDate.length) {
    //       this.keyword = `${this.searchUser} ${this.searchDate}`
    //     }
    //     this.$refs.searchKeyword.clear()
    //   }
    //   this.searchPage()
    // },
    // // 日期搜索
    // searchDate(newDate) {
    //   if (newDate && newDate.length) {
    //     this.keyword = `${newDate[0]}至${newDate[1]}`
    //     if (this.searchUser) {
    //       this.keyword = `${this.searchUser} ${newDate[0]}至${newDate[1]}`
    //     }
    //     if (this.searchKeyword) {
    //       this.keyword = `${this.searchUser} ${this.searchKeyword} ${newDate[0]}至${newDate[1]}`
    //     }
    //   } else {
    //     this.keyword = ''
    //     this.isSearch = false
    //     if (this.searchUser) {
    //       this.keyword = `${this.searchUser}`
    //     }
    //     if (this.searchKeyword) {
    //       this.keyword = `${this.searchUser} ${this.searchKeyword}`
    //     }
    //     this.$refs.searchDate.clear()
    //   }
    //   this.searchPage()
    // }
  },
  created() {
    this.initPage()
  },
  methods: {
    handleRadarClick(type) {
      this.price_data_type = type
    },
    handleFoodClick(type) {
      this.food_data_type = type
    },
    handleNbarCharClick(type) {
      if (type === 'Service') {
        this.service_report_show = !this.service_report_show
      }
      if (type === 'Food') {
        this.food_report_show = !this.food_report_show
      }
      if (type === 'Price') {
        this.price_report_show = !this.price_report_show
      }
      if (type === 'Environment') {
        this.env_report_show = !this.env_report_show
      }
    },
    closeSearchPanel() {
      this.openSearchPanel = !this.openSearchPanel
    },
    closeReportPanel() {
      this.openReportPanel = !this.openReportPanel
    },
    handleClick(row) {
      this.selected_tableData = []
      this.selected_tableData.push({
        'id': row.id,
        'create_time': row.create_time,
        'report_range': row.report_range
      })
      this.generate_report(row.id)
      this.refresh_report()
    },
    refresh() {
      this.openSearchPanel = !this.openSearchPanel
      this.openReportPanel = !this.openReportPanel
    },
    async generate_report(r_id) {
      const report = await Report.getReportDetail(r_id)
      this.overall_summary = report.overall_summary
      this.food_summary = report.food_summary
      this.overall_report = report.overall_report
      this.sentiment_report = report.sentiment_report
      this.splited_report = report.splited_report
      this.food_data_type = this.splited_report.food.review[0].entity
      this.openSearchPanel = !this.openSearchPanel
      this.openReportPanel = !this.openReportPanel
    },
    // 下拉框
    async handleCommand(eatery_id) {
      this.refresh_report()
      this.openSearchPanel = true
      this.openReportPanel = false
      this.loading = true
      this.tableData = []
      this.current_eatery_id = eatery_id
      const eatery = await Eatery.getEatery(this.current_eatery_id)
      this.eatery = eatery
      const reports = await Report.getReports(this.current_eatery_id)
      this.tableData = reports
      // reports.forEach(report => {
      //   this.tableData.push({
      //     'id': report.id,
      //     'create_time': report.create_time,
      //     'report_range': report.report_range
      //   })
      // })
      this.loading = false
    },
    refresh_report() {
      this.overall_score_switch = false
      this.sentiment_score_switch = false
      this.service_report_show = false
      this.food_report_show = false
      this.price_report_show = false
      this.env_report_show = false
      this.service_data_type = 'all'
      this.price_data_type = 'all'
      this.food_data_type = 'all'
      this.env_data_type = 'all'
    },
    // 页面初始化
    async initPage() {
      const eateries = await Eatery.getEateriesbyu_id(this.user.id)
      if (this.$route.query.eatery_id !== undefined) {
        this.current_eatery_id = this.$route.query.eatery_id
      } else {
        this.current_eatery_id = eateries[0].id
      }
      this.eateries = eateries
      const eatery = await Eatery.getEatery(this.current_eatery_id)
      this.eatery = eatery
      console.log(eatery)
      const reports = await Report.getReports(this.current_eatery_id)
      this.reports = reports
      console.log(reports)
      const table_Data = []
      reports.forEach(report => {
        table_Data.push({
          'id': report.id,
          'create_time': report.create_time,
          'report_range': report.report_range
        })
      })
      this.tableData = table_Data
      this.loading = false
    },
    // 条件检索
    async searchPage() {
      this.totalCount = 0
      this.logs = []
      this.loading = true
      this.finished = false
      // const name = this.searchUser === '全部人员' ? '' : this.searchUser
      // const res = await log.searchLogs({
      //   page: 0, // 初始化
      //   keyword: this.searchKeyword,
      //   name,
      //   start: this.searchDate[0],
      //   end: this.searchDate[1]
      // })
      // if (res) {
      //   let logs = res.items
      //   this.totalCount = res.total
      //   if (this.searchKeyword) {
      //     logs = await searchLogKeyword(this.searchKeyword, logs)
      //   }
      //   this.logs = logs
      // } else {
      //   this.finished = true
      // }
      this.isSearch = true
      this.loading = false
    },
    // 下一页
    async nextPage() {
      this.more = true
      let res
      if (this.isSearch) {
        res = await log.moreSearchPage()
      } else {
        res = await log.moreLogPage()
      }
      if (res) {
        let moreLogs = res.items
        if (this.isSearch && this.searchKeyword) {
          moreLogs = await searchLogKeyword(this.searchKeyword, moreLogs)
        }
        this.logs = this.logs.concat(moreLogs)
      } else {
        this.finished = true
      }
      this.more = false
    },
    searchByUser(user) {
      this.searchUser = user
    },
    onQueryChange(query) {
      // 处理带空格的情况
      this.searchKeyword = query.trim()
    },
    handleDateChange(date) {
      this.searchDate = date
    },
    // 清空检索
    async backInit() {
      this.searchUser = ''
      this.searchKeyword = ''
      this.searchDate = []
      this.keyword = ''
      this.logs = []
      this.isSearch = false
      this.loading = true
      await this.initPage()
      this.loading = false
    }
  }
}
</script>

<style lang="scss" scoped>
.summary{
  b {
    font-weight: bolder;
  }
}
svg{
  width:150px;
  height:150px;
}
.lin-wrap-ui /deep/ .el-card__body {
  padding-top: 20x;
  padding-bottom: 0px;
}
.lin-wrap-ui /deep/ .el-collapse {
  border-top: none;
  border-bottom: none;
  cursor: pointer;
  .el-collapse-item__header {
    border-bottom: none;
    color: #2f4e8c;
    padding-left: 10px;
  }

  .el-collapse-item__content {
    background: #e9f0f8;
    color: #2f4e8c;
    border-radius: 4px;
    padding: 10px 5px 10px 5px;
    margin-bottom: 20px;
  }
}
.log /deep/ .el-button {
  padding-top: 10px;
  padding-bottom: 10px;
}
.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 5px;
    margin-bottom: -15px;
    margin-top: -15px;

    .header-left {
      float: left;

      .title {
        height: 59px;
        line-height: 59px;
        color: #4c76af;
        font-size: 16px;
        font-weight: 500;
      }
    }

    .header-right {
      float: right;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
.log {
  .log-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    margin-bottom: -24px;

    .header-left {
      float: left;

      .title {
        height: 59px;
        line-height: 59px;
        color: #4c76af;
        font-size: 16px;
        font-weight: 500;
      }
    }

    .header-right {
      float: right;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }

  .search {
    height: 52px;
    width: 100%;
    background: rgba(57, 99, 188, 0.1);
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    margin-top: 24px;

    .search-tip {
      margin-left: 40px;
      height: 52px;
      line-height: 52px;
      color: #354058;
      font-size: 14px;

      .search-keyword {
        color: $theme;
      }

      .search-num {
        color: #f4516c;
      }
    }

    .search-back {
      margin: 8px 20px;
      height: 32px;
      background: #f4516c;
      border: none;
      border-radius: 2px;
      color: #fff;
      padding: 0 13px;
      font-size: 14px;
      cursor: pointer;
    }
  }

  .content {
    padding: 0px 15px;

    .personal {
      height: 100%;
      margin-left: -10px;
      margin-top:-30px;
      .personal-title {
        margin: 20px 0 10px 5px;
        height: 22px;
        line-height: 22px;
        font-weight: 500;
        color: #596c8e;
        font-size: 16px;
      }
      .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: 5px 0;
}
      .personal-avatar {
        width: 140px;
        height: 140px;
        margin: 0 auto 40px;
        border-radius: 75px;
        box-shadow: 0 0 30px 0 #cfd5e3;
      }
      .personal-info {
        margin: 0px 0px -5px -10px;
        .content{
          display: flex;
          justify-content: flex-start;
          .title{
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        .context{
          flex-grow:1;
          margin-left: 20px;
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        }

      }
      .personal-influence {
        display: flex;
        justify-content: left;
        padding: 10px 5px 0px 10px;
        .personal-influence-item {
          display: flex;
          flex-direction: column;
          align-items: left;
          .personal-influence-num {
            font-size: 16px;
            line-height: 28px;
            &.color1 {
              color: #00c292c4;
            }
            &.color2 {
              color: #fec108;
            }
            &.color3 {
              color: #03a9f3;
            }
            &.longcontent{
              margin-top:5px;
              font-size: 14px;
              line-height: 18px;
            }
          }
          .personal-influece-label {
            font-size: 16px;
            font-weight: 400;
            color: #87a4db;
            line-height: 17px;
          }
        }
      }
      .personal-tabs {
        margin-bottom: 20px;
      }
      .personal-tabs /deep/ .is-top {
        width: 320px;
        display: flex;
        justify-content: space-around;
      }
      .personal-tabs /deep/ .el-tabs__content {
        text-indent: 20px;
      }
    }

    article {
      position: relative;
      margin-bottom: -24px;

      section {
        padding: 0 0 36px;
        position: relative;

        &:before {
          content: '';
          width: 1px;
          top: 7px;
          bottom: -17px;
          left: 10.5px;
          background: #f3f3f3;
          position: absolute;
        }

        &:last-child:before {
          display: none;
        }

        .point-time {
          content: '';
          position: absolute;
          width: 10px;
          height: 10px;
          top: 2px;
          left: 10px;
          background: $theme;
          margin-left: -4px;
          border-radius: 50%;
        }

        time {
          width: 15%;
          display: block;
          position: absolute;

          span {
            display: block;
            text-align: right;
          }
        }

        aside {
          color: #45526b;
          margin-left: 30px;

          .things {
            font-size: 14px;
            color: #45526b;
            margin-bottom: 15px;
          }
        }

        .text-yellow {
          color: #8c98ae;
          font-size: 14px;
          line-height: 20px;
          padding-right: 30px;
          float: left;
        }

        .brief {
          font-size: 14px;
          color: #c4c9d2;
          height: 20px;
          line-height: 20px;
        }
      }
    }
  }

  .more {
    height: 40px;
    line-height: 40px;
    color: $theme;
    font-size: 14px;
    margin-left: 28px;
    cursor: pointer;
    &.nothing {
      cursor: text;
    }

    .icon-gengduo {
      display: inline;
      margin-left: 6px;
    }

    .icon-loading {
      &:before {
        display: inline-block;
        animation: spin 1s linear infinite;
      }
    }
  }
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
}

@media screen and (max-width: 1000px) {
  .date {
    display: none;
  }
}
</style>
<style>
.strong {
  color: #464dd5;
}
</style>
