<template>
  <div class="login-container">
    <el-row :gutter="30" class="login-wrapper" type="flex" justify="center">
      <el-col :span="8">
        <el-card class="box-card login-card" shadow="hover">
          <el-form
            ref="registerForm"
            :model="form"
            :rules="rules"
            class="login-form"
            autocomplete="on"
            label-position="left"
          >
            <div class="title-container">
              <h3 class="title">Welcome to Food Connoisseur</h3>
              <el-divider />
              <h5 class="sub-title">Register</h5>
            </div>

            <el-form-item prop="username">
              <span class="svg-container">
                <i class="el-icon-user" />
              </span>
              <el-input
                ref="username"
                v-model="form.username"
                placeholder="Username"
                name="username"
                type="text"
                tabindex="1"
                autocomplete="off"
              />
            </el-form-item>

            <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
              <el-form-item prop="password">
                <span class="svg-container">
                  <i class="el-icon-lock" />
                </span>
                <el-input
                  :key="passwordType"
                  ref="password"
                  v-model="form.password"
                  :type="passwordType"
                  placeholder="Password"
                  name="password"
                  tabindex="2"
                  autocomplete="off"
                  @blur="capsTooltip = false"
                />
                <span class="show-pwd" @click="showPwd">
                  <i :class="passwordType === 'password' ? 'el-icon-view' : 'el-icon-remove-outline'" />
                </span>
              </el-form-item>
            </el-tooltip>

            <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
              <el-form-item prop="confirm_password">
                <span class="svg-container">
                  <i class="el-icon-lock" />
                </span>
                <el-input
                  :key="passwordType"
                  ref="password"
                  v-model="form.confirm_password"
                  :type="passwordType"
                  placeholder="Confirm Password"
                  name="password"
                  tabindex="2"
                  autocomplete="off"
                  @blur="capsTooltip = false"
                />
                <span class="show-pwd" @click="showPwd">
                  <i :class="passwordType === 'password' ? 'el-icon-view' : 'el-icon-remove-outline'" />
                </span>
              </el-form-item>
            </el-tooltip>

            <el-form-item prop="email">
              <span class="svg-container">
                <i class="el-icon-message" />
              </span>
              <el-input
                ref="email"
                v-model="form.email"
                type="text"
                placeholder="Email"
                name="email"
                tabindex="2"
                autocomplete="off"
              />
            </el-form-item>

            <el-form-item prop="gender">
              <span class="svg-container">
                <i class="el-icon-info" />
              </span>
              <el-select v-model="form.gender" placeholder="Gender">
                <el-option
                  v-for="item in gender_options"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-form-item>

            <el-form-item prop="age">
              <span class="svg-container">
                <i class="el-icon-camera-solid" />
              </span>
              <el-input
                ref="age"
                v-model.number="form.age"
                placeholder="Age"
                name="age"
                tabindex="2"
              />
            </el-form-item>

            <el-form-item prop="phone">
              <span class="svg-container">
                <i class="el-icon-phone-outline" />
              </span>
              <el-input
                ref="phone"
                v-model.number="form.phone"
                placeholder="Phone"
                name="phone"
                tabindex="2"
              />
            </el-form-item>

            <div style="display:flex;padding-top:15px;">
              <el-button
                :loading="loading"
                type="primary"
                class="register-button"
                @click.native.prevent="registercheck()"
              >Register</el-button>
              <el-button
                type="primary"
                class="register-button"
                @click.native.prevent="back()"
              >Back</el-button>
            </div>

          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import 'vue-lazy-youtube-video/dist/style.css'
import { mapActions, mapMutations } from 'vuex'
import User from '@/lin/models/user'
import Utils from '@/lin/utils/util'

export default {
  name: 'Login',
  components: {
  },
  data() {
    var checkAge = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('Please enter your age'))
      }
      setTimeout(() => {
        if (!Number.isInteger(value)) {
          callback(new Error('Only Number'))
        } else {
          if (value < 18) {
            callback(new Error('18 or above'))
          } else {
            callback()
          }
        }
      }, 1000)
    }
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter the password'))
      } else {
        if (this.form.confirm_password !== '') {
          this.$refs.registerForm.validateField('checkPass')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter the password again'))
      } else if (value !== this.form.password) {
        callback(new Error('The two passwords you entered did not match'))
      } else {
        callback()
      }
    }
    return {
      loading: false, // 加载动画
      wait: 2000, // 2000ms之内不能重复发起请求
      throttleLogin: null, // 节流登录
      form: {
        username: '',
        password: '',
        confirm_password: '',
        email: '',
        group_id: 1,
        phone_prepend: '',
        gender: '',
        phone: ''
      },
      passwordType: 'password',
      capsTooltip: false,
      gender_options: [{
        value: '0',
        label: 'Man'
      }, {
        value: '1',
        label: 'Woman'
      }],
      rules: {
        username: [
          { required: true, message: 'Please enter your username', trigger: 'blur' }
        ],
        password: [
          { validator: validatePass, trigger: 'blur' },
          { min: 6, max: 16, message: 'Min 6 charaters,Max 16 charaters.', trigger: 'blur' }
        ],
        email: [
          { required: true, type: 'email', message: 'Please enter your email(email format please)', trigger: ['blur', 'change'] }
        ],
        age: [
          { validator: checkAge, trigger: 'blur' }
        ],
        confirm_password: [
          { validator: validatePass2, trigger: 'blur' }
        ],
        phone: [
          { required: true, message: 'Please enter your phone', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    registercheck() {
      this.$refs['registerForm'].validate((valid) => {
        if (valid) {
          this.register()
        }
      })
    },
    back() {
      this.$router.push('/login')
    },
    async getInformation() {
      try {
        // 尝试获取当前用户信息
        const user = await User.getAuths()
        this.setUserAndState(user)
        this.setUserAuths(user.auths)
      } catch (e) {
        console.log(e)
      }
    },
    async register() {
      const obj = {
        data: {
          username: this.form.username,
          password: this.form.password,
          group_id: this.form.group_id,
          confirm_password: this.form.confirm_password,
          email: this.form.email,
          gender: this.form.gender,
          phone: this.form.phone,
          age: this.form.age
        }
      }
      try {
        await User.register(obj.data)
        this.$notify({
          title: 'Register Sucessfully',
          message: 'Now you can login the system.',
          type: 'success'
        })
        this.$router.push('/login')
      } catch (e) {
        this.$message.error(e.data.msg)
        console.log(e)
      }
    },
    ...mapActions(['setUserAndState']),
    ...mapMutations({
      setUserAuths: 'SET_USER_AUTHS'
    }),
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    }
  }
}
</script>
<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-form .el-input input {
    color: $cursor;
  }
}

.register-button{
  width:50%;margin-bottom:30px;line-height:25px;
}

/* reset element-ui css */
.login-form {
  .el-input {
    display: inline-block;
    height: 25px;
    width: 85%;

    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 10px 5px 5px 10px;
      color: $light_gray;
      height: 25px;
      line-height: 25px;
      font-size: 16px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }
  .el-select{
    display: inline-block;
    width: 85%;

    .el-input {
      height:100%;
      margin-top: 5px;
      input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 15px 5px 10px 0px;
      margin-left: -35px;
      color: $light_gray;
      height: 25px;
      line-height: 25px;
      font-size: 16px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
    }
    .el-input__suffix{
      margin-right:-22px;
      margin-top: 0px;
    }
  }

  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    color: #454545;
    margin-top: 20px;
    .el-form-item__content {
      margin: 5px auto;
      .el-form-item__error{
        right: 0;
        left: auto;
        margin: 3px auto;
        font-size: 14px;
      }
    }
  }
}
</style>

<style lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_orange: rgb(243, 157, 45);

.login-container {
  height: 100%;
  width: 100%;
  background-size: auto;
  background: #1b2c5f url('../../assets/img/login/login-ba.png') no-repeat center center;
  position: relative;

  .login-wrapper {
    top: 10%;

    .login-card {
      margin-top: 50px;
      border: 0px;
      background-color: #006699;

      .login-form {
        position: relative;
        width: 400px;
        max-width: 100%;
        padding: 50px 35px 0px 25px;
        margin: 0 auto;
        overflow: hidden;
      }

      .tips {
        font-size: 14px;
        color: #fff;
        margin-bottom: 10px;

        span {
          &:first-of-type {
            margin-right: 16px;
          }
        }
      }

      .svg-container {
        padding: 10px 5px 5px 15px;
        color: $dark_gray;
        vertical-align: middle;
        width: 30px;
        display: inline-block;
        font-size: 25px;
      }

      .title-container {
        position: relative;

        .title {
          font-size: 20px;
          color: $light_orange;
          margin: -20px auto 40px auto;
          text-align: center;
          font-weight: bold;
        }
        .sub-title {
          font-size: 18px;
          color: $light_orange;
          margin: 10px auto 25px auto;
          text-align: center;
          font-weight: bold;
        }

              .el-divider--horizontal {

    display: block;
    height: 1px;
    width: 100%;
    margin: -20px auto auto 0;
}
      }

      .show-pwd {
        position: absolute;
        right: 10px;
        top: 7px;
        font-size: 16px;
        color: $dark_gray;
        cursor: pointer;
        user-select: none;
      }
    }
  }
}
</style>
