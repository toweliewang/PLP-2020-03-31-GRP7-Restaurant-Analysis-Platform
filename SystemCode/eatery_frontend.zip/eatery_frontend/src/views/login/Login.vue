<template>
  <div class="login-container">
    <el-row :gutter="30" class="login-wrapper">
      <el-col :span="11" :offset="2" class="demo-video">
        <LazyYoutubeVideo src="https://www.youtube.com/embed/Vv6DaqbcykE" />
      </el-col>
      <el-col :span="6" :offset="2">
        <el-card class="box-card login-card" shadow="hover">
          <el-form
            ref="loginForm"
            :model="form"
            class="login-form"
            autocomplete="on"
            label-position="left"
            :rules="rules"
          >
            <div class="title-container">
              <h3 class="title">Welcome to Food Connoisseur</h3>
            </div>

            <el-form-item prop="username">
              <span class="svg-container">
                <i class="el-icon-user" />
              </span>
              <el-input
                ref="username"
                v-model="form.username"
                placeholder="Username"
                name="username"
                type="text"
                tabindex="1"
                autocomplete="on"
              />
            </el-form-item>

            <el-form-item prop="password">
              <span class="svg-container">
                <i class="el-icon-lock" />
              </span>
              <el-input
                :key="passwordType"
                ref="password"
                v-model="form.password"
                :type="passwordType"
                placeholder="Password"
                name="password"
                tabindex="2"
                autocomplete="on"
                @keyup.enter.native="logincheck()"
              />
              <span class="show-pwd" @click="showPwd">
                <i :class="passwordType === 'password' ? 'el-icon-view' : 'el-icon-remove-outline'" />
              </span>
            </el-form-item>

            <div style="display:flex;padding-top:10px;">
              <el-button
                :loading="loading"
                type="primary"
                style="width:50%;margin-bottom:30px;line-height:20px;"
                @click.native.prevent="logincheck()"
              ><span style="font-weight:bold;">Login</span></el-button>
              <el-button type="primary" style="width:50%;margin-bottom:30px;line-height:20px;" @click="doRegister()">
                <span style="font-weight:bold;">Register</span>
              </el-button>
            </div>
          </el-form>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import 'vue-lazy-youtube-video/dist/style.css'
import { mapActions, mapMutations } from 'vuex'
import LazyYoutubeVideo from 'vue-lazy-youtube-video'
import User from '@/lin/models/user'
import Utils from '@/lin/utils/util'

export default {
  name: 'Login',
  components: {
    LazyYoutubeVideo
  },
  data() {
    return {
      loading: false, // 加载动画
      wait: 2000, // 2000ms之内不能重复发起请求
      throttleLogin: null, // 节流登录
      form: {
        username: '',
        password: ''
      },
      passwordType: 'password',
      capsTooltip: false,
      rules: {
        username: [
          { required: true, message: 'Please enter your username', trigger: 'blur' }
        ],
        password: [
          { required: true, message: 'Please enter password', trigger: 'blur' }
        ]
      }
    }
  },
  methods: {
    logincheck() {
      this.$refs['loginForm'].validate((valid) => {
        if (valid) {
          this.throttleLogin()
        }
      })
    },
    async login() {
      const { username, password } = this.form
      try {
        this.loading = true
        await User.getToken(username, password)
        await this.getInformation()
        this.loading = false
        this.$router.push('/about')
        this.$message.success('Login Successfully')
      } catch (e) {
        this.loading = false
        this.$message.error(e.data.msg)
      }
    },
    async getInformation() {
      try {
        // 尝试获取当前用户信息
        const user = await User.getAuths()
        this.setUserAndState(user)
        this.setUserAuths(user.auths)
      } catch (e) {
        console.log(e)
      }
    },
    doRegister() {
      this.$router.push('/register')
    },
    async register() {
      const obj = {
        data: {
          username: this.username,
          password: this.password,
          confirm_password: this.confirm_password,
          email: this.email
        }
      }
      try {
        await User.register(obj)
        this.$message.success('注册成功！')
      } catch (e) {
        console.log(e)
      }
    },
    ...mapActions(['setUserAndState']),
    ...mapMutations({
      setUserAuths: 'SET_USER_AUTHS'
    }),
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    }
  },
  created() {
    // 节流登录
    this.throttleLogin = Utils.throttle(this.login, this.wait)
  }
}
</script>
<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg: #283443;
$light_gray: #fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-form .el-input input {
    color: $cursor;
  }
}

/* reset element-ui css */
.login-form {
  .el-input {
    display: inline-block;
    height: 35px;
    width: 85%;

    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 15px 5px 5px 15px;
      color: $light_gray;
      height: 40px;
      line-height: 35px;
      font-size: 16px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }

  .el-form-item {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    margin-top: 20px;
    color: #454545;
    .el-form-item__content {
      margin: 5px auto;
      .el-form-item__error{
        right: 0;
        left: auto;
        margin: 3px auto;
        font-size: 14px;
      }
    }
  }
}
</style>

<style lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_orange: rgb(243, 157, 45);

.login-container {
  height: 100%;
  width: 100%;
  background-size: auto;
  background: #1b2c5f url('../../assets/img/login/login-ba.png') no-repeat center center;
  position: relative;

  .login-wrapper {
    top: 20%;

    .login-card {
      margin-top: 50px;
      border: 0px;
      background-color: #006699;

      .login-form {
        position: relative;
        width: 400px;
        max-width: 100%;
        padding: 50px 35px 0px 25px;
        margin: 0 auto;
        overflow: hidden;
      }

      .tips {
        font-size: 14px;
        color: #fff;
        margin-bottom: 10px;

        span {
          &:first-of-type {
            margin-right: 16px;
          }
        }
      }

      .svg-container {
        padding: 10px 5px 5px 15px;
        color: $dark_gray;
        vertical-align: middle;
        width: 30px;
        display: inline-block;
        font-size: 25px;
      }

      .title-container {
        position: relative;

        .title {
          font-size: 26px;
          color: $light_orange;
          margin: 0px auto 40px auto;
          text-align: center;
          font-weight: bold;
        }
      }

      .show-pwd {
        position: absolute;
        right: 10px;
        top: 7px;
        font-size: 16px;
        color: $dark_gray;
        cursor: pointer;
        user-select: none;
      }
    }
  }
}
</style>
