<template>
  <div class="container">
    <div class="lin-info">
      <div class="lin-info-left">
        <div class="welcome">
          <div class="welcome-title" alt="">
            Welcome
            <span style="color:#eba234;">{{ user.username }}</span>
          </div>
          <div class="subtitle">
            <div class="guide">
              Food Connoisseur
              <br>Singapore
            </div>
          </div>
        </div>
        <img class="welcome-bg" src="@/assets/img/about/header-bg.png" alt="">
      </div>
      <div class="lin-info-right">
        <div class="border-label">
          Reviews
        </div>
        <vue-danmaku
          ref="danmaku"
          v-loading="loading"
          class="demo"
          element-loading-text="Loading Reviews...."
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(0, 0, 0, 0.8)"
          :danmus="danmus"
          :config="config"
          @inited="onInit"
          @mouseIn="onMouseIn"
          @mouseOut="onMouseOut"
        />
      </div>
    </div>
    <el-row class="information">
      <el-col :span="4">
        <div class="personal">
          <div class="personal-title">Personal Info
          </div>
          <img :src="user.avatar || defaultAvatar" class="personal-avatar">
          <div class="personal-info">
            <div class="text">
              {{ user.username }}
            </div>
            <div class="text">
              {{ user.phone }}
            </div>
          </div>
          <div class="personal-influence">
            <div class="personal-influence-item">
              <div class="personal-influence-num color1">{{ user.register_time }}</div>
              <div class="personal-influece-label">Join Date</div>
            </div>
            <div class="personal-influence-item">
              <div class="personal-influence-num color3">{{ eateries.length }}</div>
              <div class="personal-influece-label">Eateries</div>
            </div>
          </div>
          <el-tabs v-model="activeName" class="personal-tabs">
            <el-tab-pane label="Eateries" name="first">
              <el-collapse v-model="activeName_eatery" accordion style="margin-top:-16px;">
                <el-collapse-item v-for="(item,i) in eateries" :key="i" :name="i">
                  <template slot="title">
                    {{ item.name }}<i class="header-icon el-icon-info" style="color:orange;" />
                  </template>
                  <div>
                    <el-button @click="handleClickReport(item.id)">Reports</el-button>
                    <el-button @click="handleClickCompetitors(item.id)">Competitors</el-button>
                  </div>
                </el-collapse-item>

              </el-collapse>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-col>
      <el-col v-if="Object.keys(current_report).length !== 0" :span="19" :offset="1">
        <div class="info-detail">
          <div class="quantity-statistics">
            <div class="quantity-item">
              <div class="quantity-detail">
                <div class="quantity-detail-box">
                  <div class="quantity-title">Service</div>
                  <div class="quantity-border-line" />
                  <div class="quantity">{{ current_report.report.service.detail.score }}/10</div>
                </div>
              </div>
              <div class="quantity-icon">
                <svg t="1584544628118" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="8946" width="200" height="200"><path d="M989.866667 447.146667c-13.653333-170.666667-139.946667-310.613333-307.2-348.16v-13.653334C682.666667 40.96 641.706667 3.413333 597.333333 3.413333 549.546667 3.413333 512 40.96 512 85.333333v13.653334C348.16 136.533333 221.866667 276.48 204.8 447.146667h785.066667zM597.333333 157.013333c10.24 0 17.066667 6.826667 17.066667 17.066667s-6.826667 17.066667-17.066667 17.066667c-129.706667 0-242.346667 85.333333-279.893333 208.213333-3.413333 6.826667-10.24 13.653333-17.066667 13.653333h-3.413333c-10.24-3.413333-13.653333-13.653333-10.24-20.48 40.96-139.946667 167.253333-235.52 310.613333-235.52zM1006.933333 481.28h-819.2c-10.24 0-17.066667 6.826667-17.066666 17.066667s6.826667 17.066667 17.066666 17.066666h27.306667L314.026667 580.266667c3.413333 3.413333 6.826667 3.413333 10.24 3.413333h546.133333c3.413333 0 6.826667 0 10.24-3.413333l81.92-64.853334h44.373333c10.24 0 17.066667-6.826667 17.066667-17.066666s-6.826667-17.066667-17.066667-17.066667z" fill="#4169E1" p-id="8947" /><path d="M1020.586667 826.026667c-23.893333-47.786667-71.68-75.093333-122.88-75.093334-10.24 0-23.893333 0-34.133334 3.413334l-187.733333 44.373333c-47.786667 10.24-98.986667 17.066667-143.36 13.653333 88.746667-6.826667 184.32-27.306667 184.32-81.92 0-51.2-98.986667-61.44-221.866667-75.093333l-102.4-10.24c-34.133333-3.413333-68.266667-10.24-98.986666-17.066667-3.413333 0-10.24 0-13.653334 3.413334s-3.413333 6.826667-6.826666 10.24c-13.653333 85.333333-40.96 194.56-58.026667 252.586666-3.413333 10.24 3.413333 17.066667 10.24 20.48l256 85.333334c34.133333 13.653333 58.026667 20.48 88.746667 20.48 44.373333 0 92.16-17.066667 204.8-64.853334l235.52-109.226666 10.24-10.24c3.413333-3.413333 3.413333-6.826667 0-10.24zM242.346667 563.2c-37.546667-34.133333-194.56-44.373333-225.28-47.786667-3.413333 0-10.24 0-13.653334 3.413334 0 3.413333-3.413333 10.24-3.413333 13.653333v385.706667c0 10.24 6.826667 17.066667 17.066667 17.066666 51.2 0 133.12 17.066667 133.12 17.066667h3.413333c6.826667 0 13.653333-3.413333 17.066667-13.653333 3.413333-10.24 68.266667-252.586667 78.506666-365.226667 0-3.413333 0-6.826667-6.826666-10.24z" fill="#4169E1" p-id="8948" /></svg>
              </div>
            </div>
            <div class="quantity-item">
              <div class="quantity-detail">
                <div class="quantity-detail-box">
                  <div class="quantity-title">Food</div>
                  <div class="quantity-border-line" />
                  <div class="quantity">{{ current_report.report.food.detail.score }}/10</div>
                </div>
              </div>
              <div class="quantity-icon">
                <svg t="1584545586303" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="11217" width="200" height="200"><path d="M0 448V384h1024v64a511.872 511.872 0 0 1-263.936 448H263.936A511.872 511.872 0 0 1 0 448z m288 512h448a32 32 0 1 1 0 64h-448a32 32 0 1 1 0-64zM64 320a256.128 256.128 0 0 1 495.872 0H64z m359.808-235.904A320 320 0 0 1 960 320H625.536a320.576 320.576 0 0 0-201.728-235.904z" p-id="11218" fill="#4169E1" /></svg>
              </div>
            </div>
            <div class="quantity-item">
              <div class="quantity-detail">
                <div class="quantity-detail-box">
                  <div class="quantity-title">Price</div>
                  <div class="quantity-border-line" />
                  <div class="quantity">{{ current_report.report.price.detail.score }}/10</div>
                </div>
              </div>
              <div class="quantity-icon">
                <svg t="1584545630655" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="13289" width="200" height="200"><path d="M631.466667 614.4c0-47.786667-47.786667-92.16-102.4-98.986667v184.32c51.2-6.826667 102.4-37.546667 102.4-85.333333zM392.533333 385.706667c0 47.786667 44.373333 88.746667 102.4 92.16V290.133333c-58.026667 6.826667-102.4 44.373333-102.4 95.573334z" fill="#4169E1" p-id="13290" /><path d="M512 17.066667C238.933333 17.066667 17.066667 238.933333 17.066667 512S238.933333 1006.933333 512 1006.933333 1006.933333 785.066667 1006.933333 512 785.066667 17.066667 512 17.066667zM665.6 614.4c0 68.266667-64.853333 109.226667-136.533333 119.466667v17.066666c0 10.24-6.826667 17.066667-17.066667 17.066667s-17.066667-6.826667-17.066667-17.066667v-17.066666c-78.506667-3.413333-136.533333-54.613333-136.533333-119.466667 0-10.24 6.826667-17.066667 17.066667-17.066667s17.066667 6.826667 17.066666 17.066667c0 47.786667 40.96 78.506667 102.4 85.333333V512c-75.093333-6.826667-136.533333-61.44-136.533333-126.293333s61.44-119.466667 136.533333-126.293334V238.933333c0-10.24 6.826667-17.066667 17.066667-17.066666s17.066667 6.826667 17.066667 17.066666v17.066667c71.68 6.826667 136.533333 51.2 136.533333 119.466667 0 10.24-6.826667 17.066667-17.066667 17.066666s-17.066667-6.826667-17.066666-17.066666c0-47.786667-51.2-78.506667-102.4-85.333334V477.866667c75.093333 10.24 136.533333 71.68 136.533333 136.533333z" fill="#4169E1" p-id="13291" /></svg>
              </div>
            </div>
            <div class="quantity-item">
              <div class="quantity-detail">
                <div class="quantity-detail-box">
                  <div class="quantity-title">Environment</div>
                  <div class="quantity-border-line" />
                  <div class="quantity">{{ current_report.report.environment.detail.score }}/10</div>
                </div>
              </div>
              <div class="quantity-icon">
                <svg t="1584545703767" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="15515" width="200" height="200"><path d="M122.4 671.6c43.8-253.1 158.4-346.5 294.2-384.7 169.7-46.7 318.2-12.7 461-80.6 86.3-41 83.4 32.5 82 43.8C938.4 419.9 847.8 579.7 656.9 656 449 739.5 242.6 585.3 94.1 827.2c-1.4 1.4-2.8 2.8-5.7 2.8H70c-4.2 0-7.1-4.2-5.7-8.5C120.9 709.8 201.5 615 304.8 538.7c93.3-69.3 203.6-121.6 330.9-164 9.9-2.8 5.7-18.4-4.2-17-97.6 22.6-186.7 52.3-268.7 99-86.3 49.4-165.5 117.3-240.4 214.9" fill="#4169E1" p-id="15516" /></svg>
              </div>
            </div>
          </div>
          <div class="article">
            <div class="article-title">Competitors</div>
            <div class="article-list">
              <map-chart
                v-loading="loading"
                element-loading-text="Loading Map...."
                element-loading-spinner="el-icon-loading"
                element-loading-background="rgba(0, 0, 0, 0.8)"
                :selectid="selected_eatery_id"
              />
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-dialog
      title="Alert"
      :visible.sync="dialogVisible"
      width="30%"
    >
      <span>You don't register any eatery, please register your eatery first</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleRegister()">Register Eatery</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import { mapActions, mapGetters } from 'vuex'
import User from '@/lin/models/user'
import Chatbot from '@/models/chatbot'
import Eatery from '@/models/eatery'
import Report from '@/models/report'
import MapChart from '@/components/echarts/MapChart'
import VueDanmaku from '@/components/vue-danmaku/lib'
import { danmus } from '@/components/vue-danmaku/assets/danmu.js'
import defaultAvatar from '@/assets/img/user/user.png'

export default {
  components: {
    MapChart,
    VueDanmaku
  },
  data() {
    return {
      dialogVisible: false,
      activeName: 'first',
      activeName_eatery: 0,
      showTeam: false,
      config: {
        channels: 5,
        loop: false,
        speed: 26,
        fontSize: 18
      },
      danmu: '',
      danmus: [],
      loading: true,
      currentUser: '',
      eateries: [],
      selected_eatery_id: '',
      current_report: {}
    }
  },
  watch: {
    async selected_eatery_id(oldValue, newValue) {
      if (newValue) {
        const report = await Report.getLatestReport(newValue)
        this.current_report = report
        this.danmus = []
        this.$refs.danmaku.stop()
        this.danmus = this.current_report.display_review
        this.$refs.danmaku.resize()
        this.$refs.danmaku.play()
      }
    }
  },
  inject: ['eventBus'],
  computed: {
    ...mapGetters(['user'])
  },
  created() {
    this.init()
  },
  mounted() {
    if (document.body.clientWidth > 1200 && document.body.clientWidth < 1330) {
      this.showTeam = true
    }
  },
  methods: {
    handleClickCompetitors(eatery_id) {
      this.selected_eatery_id = eatery_id
    },
    handleClickReport(eatery_id) {
      this.$router.push({ path: '/report', query: { eatery_id: eatery_id }})
    },
    async init() {
      // this.currentUser = User.getInformation()
      const eateries = await Eatery.getEateriesbyu_id(this.user.id)
      this.eateries = eateries
      if (this.eateries.length === 0) {
        this.dialogVisible = true
      } else {
        this.selected_eatery_id = this.eateries[0].id
        const report = await Report.getLatestReport(this.selected_eatery_id)
        this.current_report = report
        this.danmus = this.current_report.display_review
        setTimeout(() => {
          this.$refs.danmaku.resize()
          this.$refs.danmaku.play()
        }, 2000)
        setTimeout(() => {
          this.$refs.danmaku.resize()
          this.loading = false
        }, 4000)
        const feedback = await Chatbot.check_feedback()
        if (feedback.status === 1) {
          this.eventBus.$emit('hasFeedback')
        }
        this.eateries
      }
    },
    handleRegister() {
      this.dialogVisible = false
      this.$router.push('/eatery/add')
    },
    handleArticle(link) {
      window.open(link)
    },
    onInit() {
      this.$refs.danmaku.play()
    },
    onMouseIn() {
      this.$refs.danmaku.pause()
    },
    onMouseOut() {
      this.$refs.danmaku.play()
    },
    play(type) {
      switch (type) {
        case 'play':
          this.$refs.danmaku.play()
          break
        case 'pause':
          this.$refs.danmaku.pause()
          break
        case 'stop':
          this.$refs.danmaku.stop()
          break
        case 'show':
          this.$refs.danmaku.show()
          break
        case 'hide':
          this.$refs.danmaku.hide()
          break
        case 'reset':
          this.$refs.danmaku.reset()
          break
        default: break
      }
    }
  }
}
</script>

<style scoped lang="scss">
.container {
  padding: 20px;
  .lin-info {
    display: flex;
    flex: 1;
    height: 160px;
    width: 100%;
    .lin-info-left {
      position: relative;
      width: 600px;
      height: 100%;
      background: rgba(69, 119, 255, 1);
      box-shadow: 0px 2px 14px 0px rgba(243, 243, 243, 1);
      border-radius: 8px;
      .welcome {
        margin: 28px 0 0 30px;
        .welcome-title {
          color: white;
          width: 366px;
          height: 35px;
          font-size: 25px;
        }
        .subtitle {
          display: flex;
          flex-direction: column;
          margin-top: 35px;
          color:#fff;
          .guide {
            margin-right: 20px;
            font-size: 18px;
            font-weight: 500;
            line-height: 20px;
            color:#fff;
          }
          .link {
            margin-top: 6px;
            width: 160px;
            height: 22px;
            background: rgba(44, 95, 233, 1);
            border-radius: 11px;
            text-align: center;
            line-height: 20px;
            color: rgba(255, 255, 255, 1);
          }
        }
      }
      .welcome-bg {
        position: absolute;
        bottom: 0;
        right: 10px;
        width: 393px;
        height: 121px;
      }
    }
    .lin-info-right {
      flex: 1;
      margin-left: 20px;
      height: 100%;
      display: flex;
      flex-direction: column;
      position: relative;
    }
  }
  .info-detail {
    width: 100%;

    .quantity-statistics {
      display: flex;
      justify-content: space-between;
      margin-top: 0px;
      height: 90px;
      .quantity-item {
        display: flex;
        width: 23%;
        height: 100%;
        background: rgba(255, 255, 255, 1);
        box-shadow: 0px 2px 14px 0px rgba(243, 243, 243, 1);
        border-radius: 8px;
        .quantity-detail {
          flex: 1;
          .quantity-detail-box {
            margin: 12px 0 0 30px;
            .quantity-title {
              margin-bottom: 2px;
              height: 20px;
              line-height: 20px;
              color: #495468;
              font-size: 14px;
              font-weight: 400;
            }
            .quantity-border-line {
              width: 46px;
              height: 2px;
              background: rgba(73, 84, 104, 1);
            }
            .quantity {
              margin-top: 7px;
              height: 48px;
              font-size: 32px;
              color: rgba(73, 84, 104, 1);
              line-height: 38px;
              letter-spacing: 2px;
            }
          }
        }
        .quantity-icon {
          display: flex;
          justify-content: center;
          align-items: center;
          width: 90px;
          height: 100%;
          background: rgba(69, 119, 255, 0.1);
          border-top-right-radius: 8px;
          border-bottom-right-radius: 8px;
          svg {
            width: 55px;
            height:55px;
          }
        }
      }
    }
    .article {
      flex: 1;
      height: 100%;
      padding: 20px;
      background: rgba(255, 255, 255, 1);
      box-shadow: 0px 2px 14px 0px rgba(243, 243, 243, 1);
      border-radius: 8px;
      margin-top: 20px;
      .article-title {
        height: 22px;
        line-height: 22px;
        font-weight: 500;
        color: #596c8e;
        font-size: 16px;
        margin-bottom: 20px;
      }
      .article-list {
        cursor: pointer;
        .article-item {
          display: flex;
          flex-direction: row;
          justify-content: flex-start;

          .article-thumb {
            width: 120px;
            height: 120px;
            border-radius: 8px;
            margin-right: 30px;
          }
          .article-detail {
            flex: 1;
            border-bottom: 1px #ecedef solid;
            margin-bottom: 20px;
            &.article-last {
              border-bottom: none;
              margin-bottom: 0;
            }
            .article-detail-title {
              height: 22px;
              font-size: 16px;
              font-weight: 400;
              color: rgba(69, 82, 107, 1);
              line-height: 22px;
            }
            .article-detail-content {
              margin-top: 10px;
              font-size: 14px;
              font-weight: 400;
              color: rgba(140, 152, 174, 1);
              line-height: 22px;
            }
          }
          .article-tool {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            margin: 10px 0 20px 0;
            font-size: 12px;
            line-height: 17px;
            font-weight: 400;
            color: #808da3;
            .article-about {
              .iconfont {
                line-height: 17px;
                margin-right: 6px;
                font-size: 12px;
              }
            }
          }
        }
      }
    }
  }

  .information {
    margin: 25px 10px 0px;
    .personal {
      width: 320px;
      height: 100%;
      margin-left:15px;
      background: rgba(255, 255, 255, 1);
      box-shadow: 8px 8px 14px 8px rgba(243, 243, 243, 1);
      border-radius: 8px;
      .personal-title {
        margin: 0px 0 10px 25px;
        padding-top: 10px;
        height: 22px;
        line-height: 22px;
        font-weight: bolder;
        color: #596c8e;
        font-size: 16px;
      }
      .personal-avatar {
        margin: 0px 0 10px 25px;
        padding-top: 10px;
        width: 140px;
        height: 140px;
        margin: 20px auto 10px;
        border-radius: 75px;
        box-shadow: 0 0 30px 0 #cfd5e3;
      }
      .personal-info {
        margin: 20px auto 20px;
        .text{
          text-align: center;
          font-size: 16px;
          font-weight: bold;
          line-height: 20px;
        }
      }

      .personal-influence {
        display: flex;
        justify-content: space-between;
        padding: 0 30px 10px;
        .personal-influence-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          cursor: pointer;
          .personal-influence-num {
            font-size: 28px;
            line-height: 34px;
            &.color1 {
              color: #00c292;
            }
            &.color2 {
              color: #fec108;
            }
            &.color3 {
              color: #03a9f3;
            }
          }
          .personal-influece-label {
            font-size: 12px;
            font-weight: 400;
            color: #8c98ae;
            line-height: 17px;
          }
        }
      }
      .personal-tabs {
        margin-bottom: 20px;
      }
      .personal-tabs /deep/ .is-top {
        width: 320px;
        display: flex;
        justify-content: space-around;
      }
      .personal-tabs /deep/ .el-tabs__content {
        text-indent: 16px;
        min-height: 50px;
      }
    }
  }
}

@media screen and (max-width: 1200px) {
  .container .lin-info .lin-info-right {
    display: none;
  }
  .container .lin-info .lin-info-left {
    width: 100%;
  }
  .container .quantity-statistics .quantity-item {
    width: 32%;
    &:last-child {
      display: none;
    }
  }
  .container .information .personal {
    display: none;
  }
}

@media screen and (max-width: 1200px) {
  .container .lin-info .lin-info-left {
    width: 100%;
  }
}

  .demo {
    top: 0;
    z-index: 9;
    width: 100%;
    height: 100%;
    border-radius:10px;
    background: linear-gradient(45deg, #308af1, #20568b);
  }
  .border-label{
    position: absolute;
    z-index: 9999;
    width:320px;
    height:30px;
    background:rgb(65, 113, 151);
    border-radius:10px 0px 10px 0;
    box-shadow: 0px 2px 4px 0px rgba(139, 134, 134, 0.212);
    top:0px;
    left:0px;
    line-height:30px;
    font-size:16px;
    color:#FFFFFF;
    text-align:center;
    font-weight:bold;
  }
</style>
