<template>
  <div class="eatery">
    <sticky-top>
      <div class="log-header">
        <div class="header-left"><p class="title">Add Eatery</p></div>
      </div>
      <el-divider v-if="!keyword" />
    </sticky-top>
    <div class="container lin-wrap-ui">
      <el-row>
        <el-col :lg="16" :md="20" :sm="24" :xs="24">
          <el-form
            ref="form"
            :inline="true"
            :model="form"
            :label-position="left"
            label-width="180px"
            style="margin:-20px;"
            @submit.native.prevent
          >
            <el-form-item label="Eatery Name" prop="title">
              <el-autocomplete
                v-model="form.search_name"
                placeholder="Search"
                clearable
                :fetch-suggestions="querySearch"
                @select="handleSelect"
                @keyup.enter.native="search()"
              />
            </el-form-item>
            <el-form-item class="submit">
              <el-button type="primary" @click="search()">Search</el-button>
              <el-button @click="form.search_name = '';eateries = [];checkOwned = false;">Reset</el-button>
              <el-badge v-if="selected_eateries.length !== 0" :value="selected_eateries.length" style="margin-left:15px;">
                <el-button type="success" @click="handleCheckOwned()">Owned Eateries </el-button>
              </el-badge>

            </el-form-item>
          </el-form>
        </el-col>
      </el-row>
      <el-row v-if="!checkOwned" class="search-result">
        <el-col v-for="(eatery,i) in eateries" :key="i" :span="6">
          <el-card class="box-card eatery-card">
            <div class="personal">
              <div class="personal-title">
                <div style="float:left;">
                  Eatery Information
                </div>
                <div style="float:right;margin-top:-8px;">
                  <el-button icon="el-icon-check" circle @click="handleSelectEatery(eatery)" />
                </div>
              </div>
              <el-divider />
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Name</div>
                  <div class="personal-influence-num color1">{{ eatery.name }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Owner</div>
                  <div class="personal-influence-num color1">{{ eatery.owner.name }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Cuisine</div>
                  <div class="personal-influence-num color1">{{ eatery.cuisine }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Phone</div>
                  <div class="personal-influence-num color1">{{ eatery.phone }}</div>
                </div>
              </div>
              <div class="personal-influence" style="margin-bottom:15px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Rating</div>
                  <el-rate
                    v-model="eatery.rating"
                    style="margin-top:10px;"
                    disabled
                    show-score
                    text-color="#ff9900"
                    score-template="{value}"
                  />
                </div>
              </div>
              <el-divider />
              <div class="personal-influence" style="margin-bottom:15px;height:100px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Address</div>
                  <div class="personal-influence-num longcontent color3">
                    <i class="el-icon-location-information" />
                    {{ eatery.address }}</div>
                  <div class="personal-influence-num longcontent">
                    <i class="el-icon-discover" />
                    {{ eatery.from_info }}</div>
                </div>
              </div>
              <el-divider />
              <el-collapse v-model="activeName_eatery" accordion style="margin-top:-10px;">
                <el-collapse-item name="1">
                  <template slot="title" style="text-align:left;">
                    Description
                  </template>
                  <div>
                    {{ eatery.description }}
                  </div>
                </el-collapse-item>
              </el-collapse>
            </div>
          </el-card>

        </el-col>
      </el-row>
      <el-row v-if="checkOwned" class="search-result-owned">
        <el-col v-for="(eatery,i) in selected_eateries" :key="i" :span="6">
          <el-card class="box-card eatery-card">
            <div class="personal">
              <div class="personal-title">
                <div style="float:left;">
                  Eatery Information
                </div>
                <div style="float:right;margin-top:-8px;">
                  <el-button type="success" icon="el-icon-check" circle />
                </div>
              </div>
              <el-divider />
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Name</div>
                  <div class="personal-influence-num color1">{{ eatery.name }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Owner</div>
                  <div class="personal-influence-num color1">None</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Cuisine</div>
                  <div class="personal-influence-num color1">{{ eatery.cuisine }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Phone</div>
                  <div class="personal-influence-num color1">{{ eatery.phone }}</div>
                </div>
              </div>
              <div class="personal-influence" style="margin-bottom:15px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Rating</div>
                  <el-rate
                    v-model="eatery.rating"
                    style="margin-top:10px;"
                    disabled
                    show-score
                    text-color="#ff9900"
                    score-template="{value}"
                  />
                </div>
              </div>
              <el-divider />
              <div class="personal-influence" style="margin-bottom:15px;height:100px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Address</div>
                  <div class="personal-influence-num longcontent color3">
                    <i class="el-icon-location-information" />
                    {{ eatery.address }}</div>
                  <div class="personal-influence-num longcontent">
                    <i class="el-icon-discover" />
                    {{ eatery.from_info }}</div>
                </div>
              </div>
              <el-divider />
              <el-collapse v-model="activeName_eatery" accordion style="margin-top:-10px;">
                <el-collapse-item name="1">
                  <template slot="title" style="text-align:left;">
                    Description
                  </template>
                  <div>
                    {{ eatery.description }}
                  </div>
                </el-collapse-item>
              </el-collapse>
            </div>
          </el-card>

        </el-col>
      </el-row>
    </div>
    <el-dialog
      title="提示"
      :visible.sync="dialogVisible"
      width="30%"
      :before-close="handleClose"
    >
      <span>这是一段信息</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
import Eatery from '@/models/eatery'
import { mapActions, mapGetters } from 'vuex'

export default {
  data() {
    return {
      form: {
        search_name: ''
      },
      eateries: [],
      search_eateries: [],
      selected_eateries: [],
      checkOwned: false
    }
  },
  computed: {
    ...mapGetters(['user'])
  },
  async created() {
    this.loading = true
    this.loading = false
    this.load_fetch()
    this.get_selectEateries()
  },
  methods: {
    handleCheckOwned() {
      if (this.selected_eateries.length === 0) {
        this.$notify({
          title: 'Warning',
          message: "Sorry, you don't own any eatery on our platform.",
          type: 'warning'
        })
      } else {
        this.checkOwned = !this.checkOwned
      }
    },
    async get_selectEateries() {
      const selected_eateries = await Eatery.getEateriesbyu_id(this.user.id)
      this.selected_eateries = selected_eateries
      console.log(this.selected_eateries)
    },
    async search() {
      try {
        const eateries = await Eatery.getEateriesbyname(this.form.search_name)
        this.eateries = eateries
        console.log(this.eateries)
      } catch (error) {
        if (error.error_code === 10020) {
          this.tableData = []
        }
      }
    },
    handleSelect(item) {
      this.search(item.value)
    },
    async load_fetch() {
      try {
        const search_eateries = await Eatery.getEateries_simple_search()
        this.search_eateries = search_eateries
        console.log(this.search_eateries)
      } catch (error) {

      }
    },
    querySearch(queryString, cb) {
      var search_eateries = this.search_eateries
      var results = queryString ? search_eateries.filter(this.createFilter(queryString)) : search_eateries
      // 调用 callback 返回建议列表的数据
      console.log(results)
      cb(results)
    },
    createFilter(queryString) {
      return (search_eateries) => {
        return (search_eateries.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0)
      }
    },
    handleSelectEatery(eatery) {
      this.$confirm('Select this eatery?', 'Confirm', {
        confirmButtonText: 'Confirm',
        cancelButtonText: 'cancel',
        type: 'warning',
        showClose: false,
        closeOnClickModal: false,
        closeOnPressEscape: false,
        beforeClose: (action, instance, done) => {
          if (action === 'confirm') {
            instance.confirmButtonLoading = true
            instance.confirmButtonText = 'Generating...'
            this.seleteatery(done, instance, eatery)
          } else {
            done()
          }
        }
      }).then(action => {

      })
    },
    async seleteatery(done, instance, eatery) {
      const result = await Eatery.selectEatery(eatery.id)
      console.log('1231231')
      console.log(result)
      if (result.msg === 'error') {
        this.$message.error('Please choose another eatery')
      } else {
        this.$message.success('Select Eatery Successfully')
      }
      this.eateries = []
      this.form.search_name = ''
      this.load_fetch()
      this.get_selectEateries()
      done()
      instance.confirmButtonLoading = false
    },
    // async getEateries() {
    //   try {
    //     const eateries = await Eatery.getEateries()
    //     this.eateries = eateries

    //     console.log(eateries)
    //   } catch (error) {
    //     if (error.error_code === 10020) {
    //       this.tableData = []
    //     }
    //   }
    // },
    async submitForm(formName) {
      try {
        const res = await book.addBook(this.form)
        if (res.error_code === 0) {
          this.$message.success(`${res.msg}`)
          this.resetForm(formName)
        }
      } catch (error) {
        this.$message.error(error.data.msg)
        console.log(error)
      }
    },
    // 重置表单
    resetForm(formName) {
      this.$refs[formName].resetFields()
    }
  }
}
</script>

<style lang="scss" scoped>
.lin-wrap-ui /deep/ .el-card__body {
  padding-top: 20x;
  padding-bottom: 0px;
}
.lin-wrap-ui /deep/ .el-collapse {
  border-top: none;
  border-bottom: none;
  cursor: pointer;
  .el-collapse-item__header {
    border-bottom: none;
    color: #2f4e8c;
    padding-left: 10px;
  }

  .el-collapse-item__content {
    background: #e9f0f8;
    color: #2f4e8c;
    border-radius: 4px;
    padding: 10px 5px 10px 5px;
    margin-bottom: 20px;
  }
}
.container {
  .title {
    height: 59px;
    line-height: 59px;
    color: $parent-title-color;
    font-size: 16px;
    font-weight: 500;
    text-indent: 40px;
    border-bottom: 1px solid #dae1ec;
  }
}
.eatery {
  .log-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px 0 0;
    margin-bottom: -24px;

    .header-left {
      float: left;
      margin-left:-20px;

      .title {
        height: 59px;
        line-height: 59px;
        color: #4c76af;
        font-size: 16px;
        font-weight: 500;
      }
    }

    .header-right {
      float: right;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
  .eatery-card{
    margin:10px;
    width:85%;
    .personal {
      height: 100%;
      margin-left: -10px;
      margin-top:-35px;
      .personal-title {
        margin: 20px 0 10px 5px;
        height: 30px;
        line-height: 22px;
        font-weight: 500;
        color: #596c8e;
        font-size: 16px;
      }
      .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: 5px 0;
}
      .personal-avatar {
        width: 140px;
        height: 140px;
        margin: 0 auto 40px;
        border-radius: 75px;
        box-shadow: 0 0 30px 0 #cfd5e3;
      }
      .personal-info {
        margin: 0px 0px -5px -10px;
        .content{
          display: flex;
          justify-content: flex-start;
          .title{
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        .context{
          flex-grow:1;
          margin-left: 20px;
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        }

      }
      .personal-influence {
        display: flex;
        justify-content: left;
        padding: 10px 5px 0px 10px;
        .personal-influence-item {
          display: flex;
          flex-direction: column;
          align-items: left;
          .personal-influence-num {
            font-size: 16px;
            line-height: 28px;
            &.color1 {
              color: #00c292c4;
            }
            &.color2 {
              color: #fec108;
            }
            &.color3 {
              color: #03a9f3;
            }
            &.longcontent{
              margin-top:5px;
              font-size: 14px;
              line-height: 18px;
            }
          }
          .personal-influece-label {
            font-size: 16px;
            font-weight: 400;
            color: #87a4db;
            line-height: 17px;
          }
        }
      }
      .personal-tabs {
        margin-bottom: 20px;
      }
      .personal-tabs /deep/ .is-top {
        width: 320px;
        display: flex;
        justify-content: space-around;
      }
      .personal-tabs /deep/ .el-tabs__content {
        text-indent: 20px;
      }
    }
  }

</style>
