<template>
  <div class="eatery">
    <sticky-top>
      <div class="log-header">
        <div class="header-left"><p class="title">Owned Eateries</p></div>
        <div class="header-right">
          <el-button
            type="primary"
            icon="el-icon-circle-plus-outline"
            round
            @click="handleAddEatery()"
          >Add Eatery</el-button>
        </div>
      </div>
      <el-divider v-if="!keyword" />
    </sticky-top>
    <!-- 列表页面 -->
    <div v-if="!showEdit" class="container lin-wrap-ui">

      <!-- 表格 -->
      <el-row :gutter="20">
        <el-col v-for="(eatery,i) in eateries" :key="i" :span="6">
          <el-card class="box-card eatery-card">
            <div class="personal">
              <div class="personal-title">
                <div style="float:left;">
                  Eatery Information
                </div>
              </div>
              <el-divider />
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Name</div>
                  <div class="personal-influence-num color1">{{ eatery.name }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Owner</div>
                  <div class="personal-influence-num color1">None</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Cuisine</div>
                  <div class="personal-influence-num color1">{{ eatery.cuisine }}</div>
                </div>
              </div>
              <div class="personal-influence">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Phone</div>
                  <div class="personal-influence-num color1">{{ eatery.phone }}</div>
                </div>
              </div>
              <div class="personal-influence" style="margin-bottom:15px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Rating</div>
                  <el-rate
                    v-model="eatery.rating"
                    style="margin-top:10px;"
                    disabled
                    show-score
                    text-color="#ff9900"
                    score-template="{value}"
                  />
                </div>
              </div>
              <el-divider />
              <div class="personal-influence" style="margin-bottom:15px;height:100px;">
                <div class="personal-influence-item">
                  <div class="personal-influece-label">Address</div>
                  <div class="personal-influence-num longcontent color3">
                    <i class="el-icon-location-information" />
                    {{ eatery.address }}</div>
                  <div class="personal-influence-num longcontent">
                    <i class="el-icon-discover" />
                    {{ eatery.from_info }}</div>
                </div>
              </div>
              <el-divider />
              <el-collapse v-model="activeName_eatery" accordion style="margin-top:-10px;">
                <el-collapse-item name="1">
                  <template slot="title" style="text-align:left;">
                    Description
                  </template>
                  <div>
                    {{ eatery.description }}
                  </div>
                </el-collapse-item>
              </el-collapse>
            </div>
          </el-card>

        </el-col>
      </el-row>
    </div>

    <!-- 编辑页面 -->
    <book-edit v-else :edit-book-i-d="editBookID" @editClose="editClose" />
  </div>
</template>

<script>
import book from '@/models/book'
import LinTable from '@/components/base/table/lin-table'
import BookEdit from './BookEdit'
import Eatery from '@/models/eatery'
import { mapActions, mapGetters } from 'vuex'

export default {
  components: {
    LinTable,
    BookEdit
  },
  data() {
    return {
      eateries: []
    }
  },
  computed: {
    ...mapGetters(['user'])
  },
  async mounted() {
    await this.getEateries()
  },
  methods: {
    async getEateries() {
      try {
        const eateries = await Eatery.getEateriesbyu_id(this.user.id)
        this.eateries = eateries

        console.log(eateries)
      } catch (error) {
        if (error.error_code === 10020) {
          this.tableData = []
        }
      }
    },
    handleAddEatery() {
      this.$router.push('/eatery/add')
    },
    handleEdit(val) {
      console.log('val', val)
      this.showEdit = true
      this.editBookID = val.row.id
    },
    handleDelete(val) {
      this.$confirm('此操作将永久删除该图书, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async() => {
        const res = await book.delectBook(val.row.id)
        if (res.error_code === 0) {
          this.getBooks()
          this.$message({
            type: 'success',
            message: `${res.msg}`
          })
        }
      })
    },
    rowClick() {},
    editClose() {
      this.showEdit = false
      this.getBooks()
    }
  }
}
</script>

<style lang="scss" scoped>
.lin-wrap-ui /deep/ .el-card__body {
  padding-top: 20x;
  padding-bottom: 0px;
}
.lin-wrap-ui /deep/ .el-collapse {
  border-top: none;
  border-bottom: none;
  cursor: pointer;
  .el-collapse-item__header {
    border-bottom: none;
    color: #2f4e8c;
    padding-left: 10px;
  }

  .el-collapse-item__content {
    background: #e9f0f8;
    color: #2f4e8c;
    border-radius: 4px;
    padding: 10px 5px 10px 5px;
    margin-bottom: 20px;
  }
}
.container {
  padding: 0 30px;

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;

    .title {
      height: 59px;
      line-height: 59px;
      color: $parent-title-color;
      font-size: 16px;
      font-weight: 500;
    }
  }

  .pagination {
    display: flex;
    justify-content: flex-end;
    margin: 20px;
  }
  .eatery-card{
    margin:10px;
    width:85%;
    .personal {
      height: 100%;
      margin-left: -10px;
      margin-top:-35px;
      .personal-title {
        margin: 20px 0 10px 5px;
        height: 22px;
        line-height: 22px;
        font-weight: 500;
        color: #596c8e;
        font-size: 16px;
      }
      .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: 5px 0;
}
      .personal-avatar {
        width: 140px;
        height: 140px;
        margin: 0 auto 40px;
        border-radius: 75px;
        box-shadow: 0 0 30px 0 #cfd5e3;
      }
      .personal-info {
        margin: 0px 0px -5px -10px;
        .content{
          display: flex;
          justify-content: flex-start;
          .title{
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        .context{
          flex-grow:1;
          margin-left: 20px;
          text-align: left;
          font-size: 15px;
          font-weight: bold;
          line-height: 20px;
        }
        }

      }
      .personal-influence {
        display: flex;
        justify-content: left;
        padding: 10px 5px 0px 10px;
        .personal-influence-item {
          display: flex;
          flex-direction: column;
          align-items: left;
          .personal-influence-num {
            font-size: 16px;
            line-height: 28px;
            &.color1 {
              color: #00c292c4;
            }
            &.color2 {
              color: #fec108;
            }
            &.color3 {
              color: #03a9f3;
            }
            &.longcontent{
              margin-top:5px;
              font-size: 14px;
              line-height: 18px;
            }
          }
          .personal-influece-label {
            font-size: 16px;
            font-weight: 400;
            color: #87a4db;
            line-height: 17px;
          }
        }
      }
      .personal-tabs {
        margin-bottom: 20px;
      }
      .personal-tabs /deep/ .is-top {
        width: 320px;
        display: flex;
        justify-content: space-around;
      }
      .personal-tabs /deep/ .el-tabs__content {
        text-indent: 20px;
      }
    }
  }

}
.eatery /deep/ .el-button {
  padding-top: 10px;
  padding-bottom: 10px;
}
.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 5px;
    margin-bottom: -15px;
    margin-top: -15px;

    .header-left {
      float: left;

      .title {
        height: 59px;
        line-height: 59px;
        color: #4c76af;
        font-size: 16px;
        font-weight: 500;
      }
    }

    .header-right {
      float: right;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
.eatery {
  .log-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
    margin-bottom: -24px;

    .header-left {
      float: left;

      .title {
        height: 59px;
        line-height: 59px;
        color: #4c76af;
        font-size: 16px;
        font-weight: 500;
      }
    }

    .header-right {
      float: right;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
  }
}
</style>
