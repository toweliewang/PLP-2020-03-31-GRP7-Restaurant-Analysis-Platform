// import '@babel/polyfill'
import Vue from 'vue'
import ElementUI from 'element-ui'

import '@/lin/mixin'
import '@/lin/filter'
import '@/lin/plugins'
import '@/lin/directives'

import CollapseTransition from 'element-ui/lib/transitions/collapse-transition'
import router from '@/router'
import store from '@/store'
import App from '@/App.vue'

import StickyTop from '@/components/base/sticky-top/sticky-top'
import LIcon from '@/components/base/icon/lin-icon'
import SourceCode from '@/components/base/source-code/source-code'

import '@/assets/styles/share.scss'
import '@/assets/styles/index.scss' // eslint-disable-line
import '@/assets/styles/realize/element-variables.scss'
import 'element-ui/lib/theme-chalk/display.css'

import '@/assets/vendor/font-awesome/css/font-awesome.css'

import botconfig from './botconfig'

// import 'font-awesome/scss/font-awesome.scss'

// Vue.use(VueLazyload)

// import Argon from './plugins/argon-kit'

// Vue.use(Argon)

Vue.config.productionTip = false

/** For Chatbot */

Vue.prototype.botconfig = botconfig
Vue.prototype.history = () => {
  try {
    localStorage.getItem('check')
    return true
  } catch {
    return false
  }
}
Vue.prototype.lang = () => {
  if (Vue.prototype.history()) return localStorage.getItem('lang') || botconfig.app.fallback_lang
  return botconfig.app.fallback_lang
}

import locale from 'element-ui/lib/locale/lang/en'

Vue.use(ElementUI, { locale })

Vue.component(CollapseTransition.name, CollapseTransition)

// base 组件注册
Vue.component('sticky-top', StickyTop)
Vue.component('l-icon', LIcon)
Vue.component('source-code', SourceCode)

/* eslint no-unused-vars: 0 */
const AppInstance = new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

// 设置 App 实例
window.App = AppInstance
