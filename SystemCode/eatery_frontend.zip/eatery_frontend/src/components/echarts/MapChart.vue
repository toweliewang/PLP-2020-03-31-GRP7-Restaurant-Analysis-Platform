<template>
  <div class="amap-page-container">
    <div id="container" style="width:100%; height:800px" />

    <!-- <div class="toolbar">
      <button @click="init()">get map</button>

      <h4>获取地图级别与中心点坐标</h4>
      <p>当前级别：<span id="map-zoom">12</span></p>
      <p>当前中心点：<span id="map-center">103.835046,1.344954</span></p>
    </div> -->
  </div>
</template>

<script>
import echarts from 'echarts' // echarts theme
import AMap from 'AMap' // 引入高德地图
import resize from './mixins/resize'
import Eatery from '@/models/eatery'

require('echarts/theme/macarons')

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '350px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      required: true
    },
    selectid: {
      type: Number,
      required: true,
      default: 1
    }
  },
  data() {
    return {
      search: 'Singapore',
      chart: null,
      lang: 'en',
      zoom: 12,
      center: [103.9993286133, 1.3402098003],
      events: {
        init: o => {
          console.log(o.getCenter())
          console.log(this.$refs.map.$$getInstance())
          o.getCity(result => {
            console.log(result)
          })
        },
        moveend: () => {},
        zoomchange: () => {},
        click: e => {
          alert('map clicked')
        }
      },
      plugin: [
        'ToolBar',
        {
          pName: 'MapType',
          defaultType: 0,
          events: {
            init(o) {
              console.log(o)
            }
          }
        }
      ]
    }
  },
  watch: {
    selectid: {
      handler(oldvalue, newvalue) {
        this.map.clearMap()
        this.getEatery_Data()
      }
    }
  },
  created() {
    this.getEatery_Data()
  },
  mounted() {
    this.$nextTick(() => {
      setTimeout(() => {
        this.init()
        this.addEateryMakers()
      }, 500)
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    createInfoWindow(e) {
      var info = document.createElement('div')
      info.className = 'custom-info input-card content-window-card'
      var top = document.createElement('div')
      var titleD = document.createElement('div')
      var closeX = document.createElement('img')
      top.className = 'info-top'
      titleD.innerHTML = e.name
      closeX.src = 'https://webapi.amap.com/images/close2.gif'
      closeX.onclick = this.closeInfoWindow

      top.appendChild(titleD)
      top.appendChild(closeX)
      info.appendChild(top)

      // 定义中部内容
      var middle = document.createElement('div')
      middle.className = 'info-middle'
      middle.style.backgroundColor = 'white'
      middle.innerHTML = '<div><span><span style="font-weight:bold;">Address:  </span>' + e.address + '<span></div>' +
                          '<hr/><div><span style="font-weight:bold;">Rating: ' + e.rating + ' </span></div>'
      info.appendChild(middle)

      // 定义底部内容
      var bottom = document.createElement('div')
      bottom.className = 'info-bottom'
      bottom.innerHTML = '<span><span style="font-weight:bold;">Cuisine:  </span>' + e.cuisine + '<span>'
      bottom.style.position = 'relative'
      info.appendChild(bottom)
      return info
    },
    closeInfoWindow() {
      this.map.clearInfoWindow()
    },
    openInfo(e) {
      // 构建信息窗体中显示的内容
      const infoWindow = new AMap.InfoWindow({
        anchor: 'bottom-center',
        offset: new AMap.Pixel(0, -35),
        content: this.createInfoWindow(e.target.content) // 使用默认信息窗体框样式，显示信息内容
      })

      infoWindow.open(this.map, e.target.getPosition())
    },
    async getEatery_Data() {
      const eateries = await Eatery.getEateriesbycuisine(this.selectid)
      this.eateries = eateries
      const current_eatery = await Eatery.getEatery(this.selectid)
      this.current_eatery = current_eatery
      this.addEateryMakers()
    },
    addEateryMakers() {
      // 创建两个点标记

      for (var value of this.eateries) {
        var m1 = new AMap.Marker({
          position: new AMap.LngLat(value.coordinate_lng, value.coordinate_lat),
          map: this.map
        })
        m1.content = value
        this.map.add(m1)
        m1.on('click', this.openInfo)
        m1.emit('click', { target: m1 })
      }
      var startIcon = new AMap.Icon({
        // 图标尺寸
        size: new AMap.Size(19, 31),
        // 图标的取图地址
        image: 'https://webapi.amap.com/theme/v1.3/markers/n/mark_r.png',
        // 图标所用图片大小
        imageSize: new AMap.Size(19, 32)
      })
      var m2 = new AMap.Marker({
        position: new AMap.LngLat(this.current_eatery.coordinate_lng, this.current_eatery.coordinate_lat),
        icon: startIcon
      })
      this.map.add(m2)
      m2.content = this.current_eatery
      this.map.add(m2)
      m2.on('click', this.openInfo)
      m2.emit('click', { target: m2 })
      this.map.setFitView()
    },
    init() {
      const map = new AMap.Map('container', {
        center: new AMap.LngLat(103.835046, 1.344954),
        vectorMapForeign: 'English',
        viewMode: '3D',
        zoom: 12,
        pitch: 55,
        resizeEnable: false
      })
      AMap.plugin([
        'AMap.ControlBar'
      ], function() {
        // 添加 3D 罗盘控制
        map.addControl(new AMap.ControlBar())
      })
      this.map = map
    }
  }
}
</script>
<style lang="scss">

        .marker {
            position: absolute;
            top: -20px;
            right: -118px;
            color: #fff;
            padding: 4px 10px;
            box-shadow: 1px 1px 1px rgba(10, 10, 10, .2);
            white-space: nowrap;
            font-size: 12px;
            font-family: "";
            background-color: #25A5F7;
            border-radius: 3px;
        }
        .amap-info-content{
          padding: 0px;
        }

        .amap-info-close{
          display: none;
        }
        .content-window-card {
            position: relative;
            box-shadow: none;
            bottom: 0;
            left: 0;
            width: auto;
            padding: 0;
        }

        .content-window-card p {
            height: 2rem;
        }

        .custom-info {
            border: solid 1px silver;
            width: 250px;
        }

        div.info-top {
            position: relative;
            background: none repeat scroll 0 0 #F9F9F9;
            border-bottom: 1px solid #CCC;
            border-radius: 5px 5px 0 0;
        }

        .custom-info .amap-info-close{
          right:5px !important;
          top:2px !important;
        }

        div.info-top img {
            position: absolute;
            top: 8px;
            right: 6px;
            transition-duration: 0.25s;
            width: 10px;
            height: 10px;
        }

        div.info-top img:hover {
            box-shadow: 0px 0px 5px #000;
        }

        div.info-top div {
            display: inline-block;
            color: #333333;
            font-size: 16px;
            font-weight: bold;
            line-height: 18px;
            margin: 5px 5px;
        }

        div.info-middle {
            font-size: 12px;
            padding: 10px 6px;
            line-height: 20px;
            min-height: 75px;;
        }

        div.info-bottom {
            background: none repeat scroll 0 0 #F9F9F9;
            width: 100%;
            clear: both;
            text-align: left;
        }

        div.info-bottom span {
            font-size: 12px;
            margin-left: 2px;
        }

        .info-middle img {
            float: left;
            margin-right: 6px;
        }
</style>
