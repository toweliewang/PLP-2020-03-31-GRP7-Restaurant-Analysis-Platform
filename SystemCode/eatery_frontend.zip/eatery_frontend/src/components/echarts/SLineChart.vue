<template>
  <div :class="className" :style="{ height: height, width: width }" />
</template>

<script>
import echarts from 'echarts' // echarts theme
import resize from './mixins/resize'

require('echarts/theme/macarons')

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '350px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartdata: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      chart: null
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val)
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      this.setOptions(this.chartData)
    },
    setOptions({ expectedData, actualData } = {}) {
      this.chart.setOption({
        xAxis: {
          data: this.chartdata.label,
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          data: ['Service - Pos', 'Service - Neg',
            'Food - Pos', 'Food - Neg',
            'Price - Pos', 'Price - Neg',
            'Environment - Pos', 'Environment - Neg'],
          selected: { 'Service - Neg': false, 'Food - Neg': false,
            'Price - Neg': false, 'Environment - Neg': false }
        },
        series: [
          {
            name: 'Service - Pos',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: true,
            type: 'line',
            data: this.chartdata.service.positive,
            animationDuration: 1400,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Service - Neg',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: true,
            type: 'line',
            data: this.chartdata.service.negative,
            animationDuration: 1400,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Food - Pos',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: true,
            type: 'line',
            data: this.chartdata.food.positive,
            animationDuration: 1400,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Food - Neg',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: true,
            type: 'line',
            data: this.chartdata.food.negative,
            animationDuration: 1400,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Price - Pos',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: true,
            type: 'line',
            data: this.chartdata.price.positive,
            animationDuration: 1400,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Price - Neg',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: true,
            type: 'line',
            data: this.chartdata.price.negative,
            animationDuration: 1400,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Environment - Pos',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: false,
            type: 'line',
            data: this.chartdata.environment.positive,
            animationDuration: 2800,
            animationEasing: 'cubicInOut'
          },
          {
            name: 'Environment - Neg',
            itemStyle: {
              normal: {
                lineStyle: {
                  width: 2
                }
              }
            },
            smooth: false,
            type: 'line',
            data: this.chartdata.environment.negative,
            animationDuration: 2800,
            animationEasing: 'cubicInOut'
          }
        ]
      })
    }
  }
}
</script>
