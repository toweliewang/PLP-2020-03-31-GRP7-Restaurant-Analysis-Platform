<template>
  <div :class="className" :style="{height:height,width:width}" style="padding-bottom:15px;" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'

const animationDuration = 6000

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    },
    chartdata: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')

      this.chart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: { // 坐标轴指示器，坐标轴触发有效
            type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        legend: {
          data: ['Positive', 'Negative'],
          'textStyle': {
            'fontSize': 16
          }
        },
        grid: {
          left: '0%',
          right: '3%',
          bottom: '10%',
          containLabel: true
        },
        xAxis: {
          type: 'value'
        },
        yAxis: {
          type: 'category',
          axisLabel: {
            show: true,
            textStyle: {
              fontSize: 16 // 更改坐标轴文字大小
            }
          },
          data: ['Service', 'Environment', 'Food', 'Price']
        },
        series: [
          {
            name: 'Positive',
            type: 'bar',
            stack: 'Number',
            label: {
              show: true,
              position: 'insideLeft',
              formatter: function(params) {
                if (params.value > 0) {
                  return params.value
                } else {
                  return ''
                }
              }
            },
            data: this.chartdata.positive
          },
          {
            name: 'Negative',
            type: 'bar',
            stack: 'Number',
            label: {
              show: true,
              position: 'right',
              formatter: function(params) {
                if (params.value > 0) {
                  return params.value
                } else {
                  return ''
                }
              }
            },
            data: this.chartdata.negative
          }

        ]
      })

      const _self = this
      this.chart.on('click', function(params) {
        _self.$emit('handleNbarCharClick', params.name)
      })
    }
  }
}
</script>
