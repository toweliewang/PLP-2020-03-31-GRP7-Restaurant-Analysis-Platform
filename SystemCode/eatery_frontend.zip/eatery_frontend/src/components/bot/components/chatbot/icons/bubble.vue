<!-- eslint-disable vue/html-indent -->
<template>
  <svg
    id="Layer_1"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    x="0px"
    y="0px"
    viewBox="0 0 318 318"
    style="enable-background:new 0 0 318 318;"
    xml:space="preserve"
  >
    <path
      style="fill:none;stroke:#FFFFFF;stroke-width:18;stroke-miterlimit:10;"
      d="M160.9,25.2c-74.6,0-135,60.4-135,135
	c0,29,9.2,55.9,24.7,77.9l-24.8,57.5l57.9-24.7c21.9,15.3,48.5,24.3,77.2,24.3c74.6,0,135-60.4,135-135S235.5,25.2,160.9,25.2z"
    />
    <g>
      <path
        style="fill:#FFFFFF;"
        d="M93.8,160.4c0-9.3,6.3-15.8,15.1-15.8c8.8,0,14.8,6.5,14.8,15.8c0,9.1-5.8,15.8-15.1,15.8
		C99.9,176.2,93.8,169.4,93.8,160.4z"
      />
      <path
        style="fill:#FFFFFF;"
        d="M145.9,160.4c0-9.3,6.3-15.8,15.1-15.8c8.8,0,14.8,6.5,14.8,15.8c0,9.1-5.8,15.8-15.1,15.8
		C151.9,176.2,145.9,169.4,145.9,160.4z"
      />
      <path
        style="fill:#FFFFFF;"
        d="M197.9,160.4c0-9.3,6.3-15.8,15.1-15.8s14.8,6.5,14.8,15.8c0,9.1-5.8,15.8-15.1,15.8
		C203.9,176.2,197.9,169.4,197.9,160.4z"
      />
    </g>
  </svg>
</template>
