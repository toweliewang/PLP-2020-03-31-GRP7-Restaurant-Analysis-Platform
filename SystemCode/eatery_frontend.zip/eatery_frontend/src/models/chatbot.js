import { get, post } from '@/lin/plugins/axios'

// 我们通过 class 这样的语法糖使模型这个概念更加具象化，其优点：耦合性低、可维护性。
class Chatbot {
  async check_feedback() {
    const res = await get('v1/chatbot/check_feedback/')
    return res
  }
  // async getEateries() {
  //   const res = await get('v1/eatery/list')
  //   return res
  // }
  // async getEateriesbyu_id(uid) {
  //   const res = await get('v1/eatery/list/' + uid)
  //   return res
  // }
  // async getEateriesbyname(name) {
  //   const res = await get('v1/eatery/search', {
  //     q: name
  //   })
  //   return res
  // }
  // async getEateries_simple_search() {
  //   const res = await get('v1/eatery/simplesearch')
  //   return res
  // }
  // async selectEatery(eid) {
  //   return post('v1/eatery/select', {
  //     eid: eid
  //   }, {
  //     handleError: true
  //   })
  // }
  // async getEateriesbycuisine(eid) {
  //   const res = await get('v1/eatery/searchbycuisine', {
  //     q: eid
  //   })
  //   return res
  // }
}
export default new Chatbot()
