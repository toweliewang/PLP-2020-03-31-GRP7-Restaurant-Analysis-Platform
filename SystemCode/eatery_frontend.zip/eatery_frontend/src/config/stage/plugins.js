// 本文件是自动生成, 请勿修改
import LinCmsUi from '@/plugins/LinCmsUi/stage-config'
import custom from '@/plugins/custom/stage-config'

const pluginsConfig = [
  LinCmsUi,
  custom,
]

export default pluginsConfig
